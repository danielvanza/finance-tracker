"""The one interface every runner implements (SPEC.md §3.2). Shared by all four runners and the test runner."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Protocol

State = Literal["ready", "logged_out", "no_key", "missing", "rate_limited", "error"]
FailureKind = Literal[
    "logged_out", "no_key", "missing", "rate_limited", "timeout", "stopped", "policy", "unsupported", "error",
]


@dataclass
class Model:
    id: str
    label: str


@dataclass
class RunnerStatus:
    id: str
    label: str
    state: State
    detail: str
    models: list[Model] = field(default_factory=list)
    default_model: str | None = None

    def as_json(self) -> dict:
        return {
            "id": self.id, "label": self.label, "state": self.state, "detail": self.detail,
            "models": [{"id": m.id, "label": m.label} for m in self.models], "default_model": self.default_model,
        }


@dataclass
class ToolSpec:
    name: str
    description: str
    input_schema: dict  # a JSON Schema object


@dataclass
class ToolResult:
    text: str
    is_error: bool = False


@dataclass
class RunRequest:
    system: str
    prompt: str
    model: str
    tools: list[ToolSpec]
    call_tool: Callable[[str, dict], ToolResult]  # validates and runs one of `tools`; unknown names get an error result
    timeout_seconds: float
    should_stop: Callable[[], bool] = lambda: False
    on_wait: Callable[[bool], None] | None = None  # True while queued behind another run of the same login
    picture: bytes | None = None


@dataclass
class RunResult:
    text: str


class RunnerFailure(Exception):
    def __init__(self, kind: FailureKind, message: str):
        super().__init__(message)
        self.kind = kind
        self.message = message


class Runner(Protocol):
    id: str
    label: str

    def status(self) -> RunnerStatus: ...

    def run(self, request: RunRequest) -> RunResult: ...


def classify(raw: str) -> FailureKind:
    """Sorts a CLI's or API's error text into a failure kind (borrowed from Roadmap Studio's providers)."""
    import re
    text = raw.lower()
    if re.search(r"not logged in|please run /login|run .*login|sign in again|please log in|logged out|invalid api key|"
                 r"invalid x-api-key|authentication_error|invalid authentication|incorrect api key|unauthori[sz]ed|\b401\b|"
                 r"refresh token|token (is )?(expired|revoked)|no credentials|credentials? not found|oauth", text):
        return "logged_out"
    if re.search(r"rate.?limit|hit your (usage )?limit|usage limit|out of (extra )?usage|quota|too many requests|\b429\b|"
                 r"limit reached|session limit|weekly limit|overloaded|insufficient_quota", text):
        return "rate_limited"
    return "error"


Json = Any
