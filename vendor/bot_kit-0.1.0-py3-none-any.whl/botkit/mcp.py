"""A loopback MCP server that lives for one run and serves exactly the tools it is given (SPEC.md §3.4).

Streamable HTTP, JSON-RPC over POST, on 127.0.0.1 with a random port, guarded by a random bearer token. The CLI
runners point their model at it; nothing else can reach it. Extracted from household-finance's assistant/tools.py.
"""
from __future__ import annotations

import hmac
import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable

from botkit.runners.base import ToolResult, ToolSpec

SERVER_NAME = "app"


class McpServer:
    """Use as a context manager: `with McpServer(tools, call_tool) as server: server.url, server.token`."""

    def __init__(self, tools: list[ToolSpec], call_tool: Callable[[str, dict], ToolResult]) -> None:
        self._tools = {t.name: t for t in tools}
        self._call_tool = call_tool
        self._lock = threading.Lock()  # one tool call at a time, as the app's tools expect
        self.token = secrets.token_urlsafe(32)
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self._thread = threading.Thread(target=self._server.serve_forever, name="bot-mcp", daemon=True)
        self.calls: list[str] = []  # names of tools called, in order (for checks)

    @property
    def port(self) -> int:
        return self._server.server_address[1]

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/mcp"

    def allowed_tools(self) -> list[str]:
        """Claude Code's names for these tools."""
        return [f"mcp__{SERVER_NAME}__{name}" for name in self._tools]

    def __enter__(self) -> "McpServer":
        self._thread.start()
        return self

    def __exit__(self, *_) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=5)

    def _respond(self, method: str, params: dict) -> dict:
        if method == "initialize":
            return {"protocolVersion": params.get("protocolVersion", "2025-06-18"), "capabilities": {"tools": {}},
                    "serverInfo": {"name": SERVER_NAME, "version": "1"}}
        if method == "ping":
            return {}
        if method == "tools/list":
            return {"tools": [{"name": t.name, "description": t.description, "inputSchema": t.input_schema}
                              for t in self._tools.values()]}
        if method == "tools/call":
            name = params.get("name", "")
            with self._lock:
                self.calls.append(name)
                if name not in self._tools:
                    result = ToolResult(f"There is no tool called {name}.", True)
                else:
                    result = self._call_tool(name, params.get("arguments") or {})
            return {"content": [{"type": "text", "text": result.text}], "isError": result.is_error}
        return {}

    def _handler(self):
        server = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):  # tool arguments and results stay out of the logs
                pass

            def _send(self, status: int, body: dict | None = None) -> None:
                payload = json.dumps(body).encode() if body is not None else b""
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def do_GET(self):
                self._send(405)

            def do_DELETE(self):
                self._send(405)

            def do_POST(self):
                # Only a client that dialled this loopback address itself (no DNS rebinding through a browser).
                if self.headers.get("Host") not in (f"127.0.0.1:{server.port}", f"localhost:{server.port}"):
                    self._send(403)
                    return
                given = self.headers.get("Authorization") or ""
                if not hmac.compare_digest(given.encode(), f"Bearer {server.token}".encode()):
                    self._send(401)
                    return
                try:
                    message = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                except ValueError:
                    self._send(400)
                    return
                if "id" not in message:
                    self._send(202)
                    return
                self._send(200, {"jsonrpc": "2.0", "id": message["id"],
                                 "result": server._respond(message.get("method", ""), message.get("params") or {})})

        return Handler
