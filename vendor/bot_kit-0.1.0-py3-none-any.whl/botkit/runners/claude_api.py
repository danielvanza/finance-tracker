"""`claude-api`: the Anthropic Messages API with tool use, run in-process over httpx (SPEC §3.1, §3.4).

Only the app's tools are declared, and the tool loop runs here: a call to a name that was not declared gets an error
result and is never run. No server tools are ever declared, so a server tool block in a reply ends the run (`policy`).
"""
from __future__ import annotations

import base64
import hashlib
import threading
import time

import httpx

from botkit.runners.base import Model, RunnerFailure, RunnerStatus, RunRequest, RunResult, classify
from botkit.runners.common import Abandoned, StatusCache, abandonable, clean, failure, picture_type
from botkit.runners.config import RunnerConfig

ID = "claude-api"
LABEL = "Claude API"
API_VERSION = "2026-10-21"
MAX_TOKENS = 16000
MAX_ROUNDS = 100  # tool rounds in one reply; the time limit normally ends a run long before this
KEY_CHECK_TTL = 600.0


def api_failure(status: int, body: str, label: str):
    """Sorts an HTTP error from either API into a failure kind."""
    if status in (401, 403):
        return failure("logged_out", label, False, f"HTTP {status}: {body}")
    if status == 429:
        return failure("rate_limited", label, False, f"HTTP {status}: {body}")
    lowered = body.lower()
    if "credit balance" in lowered or "insufficient_quota" in lowered or "billing" in lowered:
        return failure("rate_limited", label, False, f"HTTP {status}: {body}")
    kind = classify(body) if status < 500 else "error"
    return failure(kind, label, False, f"HTTP {status}: {body}")


class ClaudeApiRunner:
    id = ID
    label = LABEL

    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self._cache = StatusCache()
        self._key_check: tuple[str, float, str, str] | None = None  # (key hash, until, state, detail)
        self._key_lock = threading.Lock()

    @property
    def _base(self) -> str:
        return self.config.anthropic_base_url.rstrip("/")

    def _headers(self) -> dict[str, str]:
        return {"x-api-key": self.config.anthropic_api_key or "", "anthropic-version": API_VERSION,
                "content-type": "application/json"}

    def _base_status(self, state: str, detail: str) -> RunnerStatus:
        models = [Model(m, m) for m in self.config.anthropic_models]
        return RunnerStatus(ID, LABEL, state, detail, models, models[0].id if models else None)  # type: ignore[arg-type]

    def status(self) -> RunnerStatus:
        return self._cache.get(self._compute_status)

    def _compute_status(self) -> RunnerStatus:
        key = self.config.anthropic_api_key
        if not key:
            return self._base_status("no_key", "No API key is set (ANTHROPIC_API_KEY).")
        state, detail = self._check_key(key)
        return self._base_status(state, detail)

    def _check_key(self, key: str) -> tuple[str, str]:
        """GET /v1/models with the key: free, and tells a refused key from a working one. Cached for 10 minutes."""
        digest = hashlib.sha256(key.encode()).hexdigest()
        with self._key_lock:
            if self._key_check and self._key_check[0] == digest and time.monotonic() < self._key_check[1]:
                return self._key_check[2], self._key_check[3]
        try:
            response = httpx.get(f"{self._base}/v1/models", headers=self._headers(), timeout=10)
            if response.status_code == 200:
                state, detail = "ready", "API key accepted."
            else:
                error = api_failure(response.status_code, response.text, LABEL)
                state = error.kind if error.kind in ("logged_out", "rate_limited") else "error"
                detail = {"logged_out": "The API refused the key.", "rate_limited": "The API key has reached its limit."}.get(
                    state, f"The API answered {response.status_code}.")
        except httpx.HTTPError as e:
            state, detail = "error", f"The API could not be reached ({type(e).__name__})."
        with self._key_lock:
            self._key_check = (digest, time.monotonic() + KEY_CHECK_TTL, state, detail)
        return state, detail

    def run(self, request: RunRequest) -> RunResult:
        try:
            result = self._run(request)
        except RunnerFailure as e:
            if e.kind in ("logged_out", "rate_limited", "no_key"):
                self._key_check = None
            self._cache.note_failure(e, self._base_status("error", ""))
            raise
        self._cache.note_success()
        return result

    def _run(self, request: RunRequest) -> RunResult:
        if not self.config.anthropic_api_key:
            raise failure("no_key", LABEL, False, "no ANTHROPIC_API_KEY")
        content: list[dict] = []
        if request.picture is not None:
            kind = picture_type(request.picture)
            if kind is None:
                raise failure("unsupported", LABEL, False, "not a PNG, JPEG, GIF or WebP picture",
                              f"{LABEL} cannot read this kind of picture, so it cannot answer this one. Nothing changed.")
            content.append({"type": "image", "source": {"type": "base64", "media_type": kind,
                                                        "data": base64.b64encode(request.picture).decode()}})
        content.append({"type": "text", "text": request.prompt})
        messages: list[dict] = [{"role": "user", "content": content}]
        declared = {t.name for t in request.tools}
        tools = [{"name": t.name, "description": t.description, "input_schema": t.input_schema} for t in request.tools]
        deadline = time.monotonic() + request.timeout_seconds

        for _ in range(MAX_ROUNDS):
            self._check_stop(request, deadline)
            body = {"model": request.model, "max_tokens": MAX_TOKENS, "system": request.system, "messages": messages}
            if tools:
                body["tools"] = tools
            reply = self._post(body, deadline, request)
            blocks = reply.get("content") or []
            calls = []
            for block in blocks:
                kind = block.get("type") if isinstance(block, dict) else None
                if kind == "tool_use":
                    calls.append(block)
                elif isinstance(kind, str) and kind.endswith(("tool_use", "tool_result")):
                    raise failure("policy", LABEL, False, f"the reply used a tool the app did not list ({kind})")
            messages.append({"role": "assistant", "content": blocks})
            if reply.get("stop_reason") != "tool_use" or not calls:
                return RunResult("".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip())
            results = []
            for call in calls:
                self._check_stop(request, deadline)
                name = str(call.get("name"))
                if name not in declared:
                    text, is_error = f"There is no tool called {name}.", True
                else:
                    args = call.get("input") if isinstance(call.get("input"), dict) else {}
                    result = request.call_tool(name, args)
                    text, is_error = result.text, result.is_error
                results.append({"type": "tool_result", "tool_use_id": call.get("id"), "content": text,
                                **({"is_error": True} if is_error else {})})
            messages.append({"role": "user", "content": results})
        raise failure("error", LABEL, False, f"more than {MAX_ROUNDS} tool rounds in one reply")

    def _check_stop(self, request: RunRequest, deadline: float) -> None:
        if request.should_stop():
            raise failure("stopped", LABEL, False, "stopped on request")
        if time.monotonic() >= deadline:
            raise failure("timeout", LABEL, False, f"stopped after {request.timeout_seconds:.0f} seconds")

    def _post(self, body: dict, deadline: float, request: RunRequest) -> dict:
        def call() -> httpx.Response:
            remaining = max(1.0, deadline - time.monotonic())
            return httpx.post(f"{self._base}/v1/messages", headers=self._headers(), json=body,
                              timeout=httpx.Timeout(remaining, connect=min(10.0, remaining)))
        try:
            response = abandonable(call, deadline, request.should_stop)
        except Abandoned as e:
            if e.why == "stopped":
                raise failure("stopped", LABEL, False, "stopped on request") from None
            raise failure("timeout", LABEL, False, f"stopped after {request.timeout_seconds:.0f} seconds") from None
        except httpx.TimeoutException:
            raise failure("timeout", LABEL, False, f"stopped after {request.timeout_seconds:.0f} seconds") from None
        except httpx.HTTPError as e:
            raise failure("error", LABEL, False, f"{type(e).__name__}: {e}") from None
        if response.status_code != 200:
            raise api_failure(response.status_code, clean(response.text), LABEL)
        try:
            reply = response.json()
        except ValueError:
            raise failure("error", LABEL, False, "the API answered with something that is not JSON") from None
        if not isinstance(reply, dict):
            raise failure("error", LABEL, False, "unexpected reply")
        return reply
