"""`openai-api`: the OpenAI Responses API with function tools, run in-process over httpx (SPEC §3.1, §3.4).

Only the app's tools are declared (as function tools), and the tool loop runs here: a call to a name that was not
declared gets an error result and is never run. No built-in tools are ever declared, so a built-in tool call in a reply
ends the run (`policy`). Nothing is stored at OpenAI (`store: false`); reasoning is handed back encrypted between rounds.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
import threading
import time

import httpx

from botkit.runners.base import Model, RunnerFailure, RunnerStatus, RunRequest, RunResult, classify
from botkit.runners.claude_api import api_failure
from botkit.runners.common import Abandoned, StatusCache, abandonable, clean, failure, picture_type
from botkit.runners.config import RunnerConfig

ID = "openai-api"
LABEL = "OpenAI API"
MAX_ROUNDS = 100
KEY_CHECK_TTL = 600.0
# Models from /v1/models that can answer a conversation with tools; the rest (audio, images, embeddings…) are left out.
_CHAT_MODEL = re.compile(r"^(gpt-|o\d|chatgpt-)")
_NOT_CHAT = re.compile(r"audio|realtime|transcribe|tts|image|embedding|search|moderation|instruct|dall-e|whisper|codex-mini")


class OpenAiApiRunner:
    id = ID
    label = LABEL

    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self._cache = StatusCache()
        self._key_check: tuple[str, float, str, str, list[Model]] | None = None  # key hash, until, state, detail, models
        self._key_lock = threading.Lock()

    @property
    def _base(self) -> str:
        return self.config.openai_base_url.rstrip("/")

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.config.openai_api_key or ''}", "Content-Type": "application/json"}

    def _configured_models(self) -> list[Model]:
        return [Model(m, m) for m in self.config.openai_models]

    def _base_status(self, state: str, detail: str, models: list[Model] | None = None) -> RunnerStatus:
        models = models if models is not None else self._configured_models()
        return RunnerStatus(ID, LABEL, state, detail, models, models[0].id if models else None)  # type: ignore[arg-type]

    def status(self) -> RunnerStatus:
        return self._cache.get(self._compute_status)

    def _compute_status(self) -> RunnerStatus:
        key = self.config.openai_api_key
        if not key:
            return self._base_status("no_key", "No API key is set (OPENAI_API_KEY).")
        state, detail, models = self._check_key(key)
        return self._base_status(state, detail, self._configured_models() or models)

    def _check_key(self, key: str) -> tuple[str, str, list[Model]]:
        """GET /v1/models with the key: tells a refused key from a working one and lists the models. Cached 10 minutes."""
        digest = hashlib.sha256(key.encode()).hexdigest()
        with self._key_lock:
            if self._key_check and self._key_check[0] == digest and time.monotonic() < self._key_check[1]:
                return self._key_check[2], self._key_check[3], self._key_check[4]
        models: list[Model] = []
        try:
            response = httpx.get(f"{self._base}/v1/models", headers=self._headers(), timeout=10)
            if response.status_code == 200:
                state, detail = "ready", "API key accepted."
                ids = sorted({str(m.get("id")) for m in response.json().get("data", []) if isinstance(m, dict)})
                models = [Model(i, i) for i in ids if _CHAT_MODEL.match(i) and not _NOT_CHAT.search(i)]
            else:
                error = api_failure(response.status_code, response.text, LABEL)
                state = error.kind if error.kind in ("logged_out", "rate_limited") else "error"
                detail = {"logged_out": "The API refused the key.", "rate_limited": "The API key has reached its limit."}.get(
                    state, f"The API answered {response.status_code}.")
        except (httpx.HTTPError, ValueError, AttributeError) as e:
            state, detail = "error", f"The API could not be reached ({type(e).__name__})."
        with self._key_lock:
            self._key_check = (digest, time.monotonic() + KEY_CHECK_TTL, state, detail, models)
        return state, detail, models

    def run(self, request: RunRequest) -> RunResult:
        try:
            result = self._run(request)
        except RunnerFailure as e:
            if e.kind in ("logged_out", "rate_limited", "no_key"):
                self._key_check = None
            self._cache.note_failure(e, self._base_status("error", ""))
            raise
        self._cache.note_success()
        return result

    def _run(self, request: RunRequest) -> RunResult:
        if not self.config.openai_api_key:
            raise failure("no_key", LABEL, False, "no OPENAI_API_KEY")
        content: list[dict] = [{"type": "input_text", "text": request.prompt}]
        if request.picture is not None:
            kind = picture_type(request.picture)
            if kind is None:
                raise failure("unsupported", LABEL, False, "not a PNG, JPEG, GIF or WebP picture",
                              f"{LABEL} cannot read this kind of picture, so it cannot answer this one. Nothing changed.")
            content.append({"type": "input_image",
                            "image_url": f"data:{kind};base64,{base64.b64encode(request.picture).decode()}"})
        items: list[dict] = [{"role": "user", "content": content}]
        declared = {t.name for t in request.tools}
        tools = [{"type": "function", "name": t.name, "description": t.description, "parameters": t.input_schema,
                  "strict": False} for t in request.tools]
        deadline = time.monotonic() + request.timeout_seconds

        for _ in range(MAX_ROUNDS):
            self._check_stop(request, deadline)
            body: dict = {"model": request.model, "instructions": request.system, "input": items, "store": False,
                          "include": ["reasoning.encrypted_content"]}
            if tools:
                body["tools"] = tools
            reply = self._post(body, deadline, request)
            if reply.get("status") == "failed":
                error = reply.get("error") or {}
                message = str(error.get("message") or error.get("code") or "the response failed")
                raise failure(classify(message), LABEL, False, message)
            output = [o for o in reply.get("output") or [] if isinstance(o, dict)]
            calls, texts = [], []
            for item in output:
                kind = item.get("type")
                if kind == "function_call":
                    calls.append(item)
                elif kind == "message":
                    for part in item.get("content") or []:
                        if isinstance(part, dict) and part.get("type") in ("output_text", "refusal"):
                            texts.append(str(part.get("text") or part.get("refusal") or ""))
                elif isinstance(kind, str) and (kind.endswith("_call") or kind.endswith("_call_output")):
                    raise failure("policy", LABEL, False, f"the reply used a tool the app did not list ({kind})")
            if not calls:
                if reply.get("status") == "incomplete" and not texts:
                    reason = (reply.get("incomplete_details") or {}).get("reason", "unknown")
                    raise failure("error", LABEL, False, f"the response was incomplete ({reason})")
                return RunResult("".join(texts).strip())
            items += output
            for call in calls:
                self._check_stop(request, deadline)
                name = str(call.get("name"))
                if name not in declared:
                    text, is_error = f"There is no tool called {name}.", True
                else:
                    try:
                        args = json.loads(call.get("arguments") or "{}")
                    except (TypeError, ValueError):
                        args = None
                    if not isinstance(args, dict):
                        text, is_error = "The arguments were not a JSON object.", True
                    else:
                        result = request.call_tool(name, args)
                        text, is_error = result.text, result.is_error
                items.append({"type": "function_call_output", "call_id": call.get("call_id"),
                              "output": f"Error: {text}" if is_error else text})
        raise failure("error", LABEL, False, f"more than {MAX_ROUNDS} tool rounds in one reply")

    def _check_stop(self, request: RunRequest, deadline: float) -> None:
        if request.should_stop():
            raise failure("stopped", LABEL, False, "stopped on request")
        if time.monotonic() >= deadline:
            raise failure("timeout", LABEL, False, f"stopped after {request.timeout_seconds:.0f} seconds")

    def _post(self, body: dict, deadline: float, request: RunRequest) -> dict:
        def call() -> httpx.Response:
            remaining = max(1.0, deadline - time.monotonic())
            return httpx.post(f"{self._base}/v1/responses", headers=self._headers(), json=body,
                              timeout=httpx.Timeout(remaining, connect=min(10.0, remaining)))
        try:
            response = abandonable(call, deadline, request.should_stop)
        except Abandoned as e:
            if e.why == "stopped":
                raise failure("stopped", LABEL, False, "stopped on request") from None
            raise failure("timeout", LABEL, False, f"stopped after {request.timeout_seconds:.0f} seconds") from None
        except httpx.TimeoutException:
            raise failure("timeout", LABEL, False, f"stopped after {request.timeout_seconds:.0f} seconds") from None
        except httpx.HTTPError as e:
            raise failure("error", LABEL, False, f"{type(e).__name__}: {e}") from None
        if response.status_code != 200:
            raise api_failure(response.status_code, clean(response.text), LABEL)
        try:
            reply = response.json()
        except ValueError:
            raise failure("error", LABEL, False, "the API answered with something that is not JSON") from None
        if not isinstance(reply, dict):
            raise failure("error", LABEL, False, "unexpected reply")
        return reply
