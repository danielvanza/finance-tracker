"""What the four model runners share: plain reasons, the status cache, picture types and abandoning a slow call."""
from __future__ import annotations

import re
import threading
import time
from typing import Callable, TypeVar

from botkit.runners.base import FailureKind, RunnerFailure, RunnerStatus

STATUS_TTL = 60.0  # SPEC §3.2: status() results are cached for 60 s
RATE_LIMIT_TTL = 15 * 60.0  # a cached rate_limited clears after 15 minutes, or on a successful run
UNAVAILABLE = ("logged_out", "no_key", "missing", "rate_limited")
POLL = 0.2  # how often should_stop() and the time limit are checked, in seconds


def plain_reason(kind: FailureKind, label: str, cli: bool) -> str:
    """The `error` message a person sees (SPEC §3.2, plain reasons)."""
    if kind == "logged_out":
        if cli:
            return f"{label} is logged out on this machine, so it cannot answer until someone logs in again. Nothing changed."
        return f"{label} refused its API key, so it cannot answer. Nothing changed."
    return {
        "no_key": f"{label} has no API key set up, so it cannot answer. Nothing changed.",
        "missing": f"{label} is not installed on this machine, so it cannot answer. Nothing changed.",
        "rate_limited": f"{label} has reached its usage limit, so it cannot answer until the limit resets. Nothing changed.",
        "unsupported": f"{label} cannot read pictures, so it cannot answer this one. Nothing changed.",
        "policy": f"{label} tried to use something it is not allowed to, so I stopped it. Nothing changed.",
        "timeout": f"{label} reached the time limit before it finished.",
        "stopped": f"{label} was stopped before it finished.",
    }.get(kind, f"{label} could not be reached. Nothing changed.")


def failure(kind: FailureKind, label: str, cli: bool, detail: str = "", message: str | None = None) -> RunnerFailure:
    """A RunnerFailure whose message is the plain reason; `detail` (for logs, never the person) says what happened."""
    error = RunnerFailure(kind, message or plain_reason(kind, label, cli))
    error.detail = clean(detail)  # type: ignore[attr-defined]
    return error


def clean(raw: str, limit: int = 600) -> str:
    text = re.sub(r"\x1b\[[0-9;]*m", "", raw or "").strip()
    return text if len(text) <= limit else text[:limit] + "…"


class StatusCache:
    """Keeps a runner's status for 60 s. A run that finds the runner unavailable updates it at once (so the picker greys
    it out); a rate limit is kept for 15 minutes unless a run succeeds first."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._status: RunnerStatus | None = None
        self._until = 0.0

    def get(self, compute: Callable[[], RunnerStatus]) -> RunnerStatus:
        with self._lock:
            if self._status is not None and time.monotonic() < self._until:
                return self._status
        status = compute()
        self._store(status)
        return status

    def _store(self, status: RunnerStatus) -> None:
        with self._lock:
            self._status = status
            self._until = time.monotonic() + (RATE_LIMIT_TTL if status.state == "rate_limited" else STATUS_TTL)

    def note_failure(self, error: RunnerFailure, base: RunnerStatus) -> None:
        """After a failed run: a failure that means "unavailable" becomes the cached status straight away."""
        if error.kind in UNAVAILABLE:
            base.state = error.kind  # type: ignore[assignment]
            base.detail = getattr(error, "detail", "") or error.message
            self._store(base)

    def note_success(self) -> None:
        with self._lock:
            if self._status is not None and self._status.state != "ready":
                self._status = None


_PICTURE_TYPES = {b"\x89PNG": "image/png", b"\xff\xd8\xff": "image/jpeg", b"GIF8": "image/gif"}


def picture_type(picture: bytes) -> str | None:
    """The kind of picture these bytes are, if it is one the models can look at (PNG, JPEG, GIF, WebP)."""
    if picture[:4] == b"RIFF" and picture[8:12] == b"WEBP":
        return "image/webp"
    return next((kind for magic, kind in _PICTURE_TYPES.items() if picture.startswith(magic)), None)


T = TypeVar("T")


class Abandoned(Exception):
    def __init__(self, why: str):  # "stopped" | "timeout"
        super().__init__(why)
        self.why = why


def abandonable(fn: Callable[[], T], deadline: float, should_stop: Callable[[], bool]) -> T:
    """Runs fn in a thread and waits for it, checking should_stop() and the deadline a few times a second.
    When either says so the call is abandoned (left to finish on its own, its result ignored) and Abandoned raised."""
    box: dict = {}

    def target() -> None:
        try:
            box["value"] = fn()
        except BaseException as e:  # handed back to the caller
            box["error"] = e

    thread = threading.Thread(target=target, name="bot-api-call", daemon=True)
    thread.start()
    while True:
        thread.join(POLL)
        if not thread.is_alive():
            break
        if should_stop():
            raise Abandoned("stopped")
        if time.monotonic() >= deadline:
            raise Abandoned("timeout")
    if "error" in box:
        raise box["error"]
    return box["value"]
