"""The runners an app can pick from, and what is known about whether each can answer (SPEC.md §3.2).

Statuses are cached for 60 s so the picker stays cheap. A run that fails because the runner cannot answer updates
the cache at once; a usage limit is remembered for 15 minutes or until a run succeeds. There is never a fallback:
a reply runs on the runner its conversation chose, or fails with that runner's reason.
"""
from __future__ import annotations

import importlib
import logging
import threading
import time
from dataclasses import replace

from botkit import words
from botkit.runners.base import Model, RunnerFailure, RunnerStatus, RunRequest, RunResult
from botkit.runners.config import RunnerConfig

logger = logging.getLogger("botkit.runners")

STATUS_SECONDS = 60
LIMITED_SECONDS = 15 * 60
UNAVAILABLE = ("logged_out", "no_key", "missing", "rate_limited")

# id → (label, module, class); the order is the picker's
KNOWN = {
    "claude-cli": ("Claude Code", "botkit.runners.claude_cli", "ClaudeCliRunner"),
    "claude-api": ("Claude API", "botkit.runners.claude_api", "ClaudeApiRunner"),
    "codex-cli": ("Codex", "botkit.runners.codex_cli", "CodexCliRunner"),
    "openai-api": ("OpenAI API", "botkit.runners.openai_api", "OpenAiApiRunner"),
    "script": ("Test script", "botkit.runners.script", "ScriptRunner"),
}
API_RUNNERS = ("claude-api", "openai-api")


class _Unavailable:
    """Stands in for a runner whose code could not be loaded, so the picker can say so and a run fails plainly."""

    def __init__(self, runner_id: str, label: str, state: str, detail: str, models: list[str]) -> None:
        self.id, self.label = runner_id, label
        self._status = RunnerStatus(runner_id, label, state, detail, [Model(m, m) for m in models],
                                    models[0] if models else None)

    def status(self) -> RunnerStatus:
        return self._status

    def run(self, request: RunRequest) -> RunResult:
        raise RunnerFailure(self._status.state if self._status.state != "ready" else "error", self._status.detail)


class Registry:
    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self.ids = [i for i in KNOWN if i != "script" or config.script_runner]
        self._runners: dict[str, object] = {}
        self._cache: dict[str, tuple[float, RunnerStatus]] = {}
        self._limited_until: dict[str, float] = {}
        self._lock = threading.Lock()

    def label(self, runner_id: str) -> str:
        return KNOWN[runner_id][0] if runner_id in KNOWN else runner_id

    def _configured_models(self, runner_id: str) -> list[str]:
        c = self.config
        return {"claude-cli": c.claude_models, "claude-api": c.anthropic_models, "openai-api": c.openai_models,
                "script": ["script"]}.get(runner_id, [])

    def get(self, runner_id: str):
        """The runner, built on first use. None for an id that is not registered."""
        if runner_id not in self.ids:
            return None
        with self._lock:
            if runner_id not in self._runners:
                self._runners[runner_id] = self._build(runner_id)
            return self._runners[runner_id]

    def _build(self, runner_id: str):
        label, module_name, class_name = KNOWN[runner_id]
        try:
            module = importlib.import_module(module_name)
        except ImportError as e:
            logger.warning("[bot] runner %s cannot be loaded: %s", runner_id, e)
            return _Unavailable(runner_id, label, "missing", f"This runner's code ({module_name}) is not installed.",
                                self._configured_models(runner_id))
        try:
            return getattr(module, class_name)(self.config)
        except Exception as e:
            logger.exception("[bot] runner %s could not be set up", runner_id)
            return _Unavailable(runner_id, label, "error", f"This runner could not be set up: {e}",
                                self._configured_models(runner_id))

    def status(self, runner_id: str) -> RunnerStatus:
        now = time.monotonic()
        with self._lock:
            cached = self._cache.get(runner_id)
        if cached is None or now - cached[0] > STATUS_SECONDS:
            runner = self.get(runner_id)
            try:
                status = runner.status()
            except Exception as e:
                logger.exception("[bot] status of %s failed", runner_id)
                status = RunnerStatus(runner_id, self.label(runner_id), "error", f"Its status could not be read: {e}",
                                      [Model(m, m) for m in self._configured_models(runner_id)])
            with self._lock:
                self._cache[runner_id] = (now, status)
            cached = (now, status)
        status = cached[1]
        with self._lock:
            limited = self._limited_until.get(runner_id, 0) > now
        if limited and status.state == "ready":
            status = replace(status, state="rate_limited", detail=self.reason(runner_id, "rate_limited"))
        return status

    def statuses(self) -> list[RunnerStatus]:
        return [self.status(i) for i in self.ids]

    def default_model(self, runner_id: str) -> str | None:
        if runner_id == self.config.default_runner and self.config.default_model:
            return self.config.default_model
        if runner_id not in self.ids:
            return None
        configured = self._configured_models(runner_id)
        if configured:
            return configured[0]
        status = self.status(runner_id)
        return status.default_model or (status.models[0].id if status.models else None)

    def check_choice(self, runner_id: str, model: str) -> str | None:
        """Why this runner and model cannot be picked, or None. An unavailable runner may still be picked."""
        if runner_id not in self.ids:
            return f"There is no runner called {runner_id}."
        models = [m.id for m in self.status(runner_id).models] or self._configured_models(runner_id)
        # A runner that knows no models (an API runner without a key) may still be picked, so it can say why it cannot run.
        if models and (not model or model not in models):
            return f"{self.label(runner_id)} has no model called {model}."
        return None

    def note_failure(self, runner_id: str, kind: str) -> None:
        """A run showed the runner cannot answer: the picker greys it out from now on."""
        if kind not in UNAVAILABLE or runner_id not in self.ids:
            return
        now = time.monotonic()
        with self._lock:
            cached = self._cache.get(runner_id)
            models = cached[1].models if cached else [Model(m, m) for m in self._configured_models(runner_id)]
            default = cached[1].default_model if cached else None
            self._cache[runner_id] = (now, RunnerStatus(runner_id, self.label(runner_id), kind,
                                                        self.reason(runner_id, kind), models, default))
            if kind == "rate_limited":
                self._limited_until[runner_id] = now + LIMITED_SECONDS

    def note_success(self, runner_id: str) -> None:
        with self._lock:
            if self._limited_until.pop(runner_id, None) is not None:
                self._cache.pop(runner_id, None)
            elif runner_id in self._cache and self._cache[runner_id][1].state in UNAVAILABLE:
                self._cache.pop(runner_id, None)

    def reason(self, runner_id: str, kind: str, message: str = "") -> str:
        """The plain words for why a runner could not answer."""
        label = self.label(runner_id)
        if kind == "logged_out" and runner_id in API_RUNNERS:
            return words.API_LOGGED_OUT.format(label=label)
        if kind == "unsupported" and message.startswith(label):  # the runner's own plain reason
            return message if message.endswith("Nothing changed.") else f"{message.rstrip('.')}. Nothing changed."
        return words.REASONS.get(kind, words.REASONS["error"]).format(label=label)
