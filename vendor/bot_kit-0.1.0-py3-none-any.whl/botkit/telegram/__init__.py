"""The Telegram front (SPEC.md §11). An app runs it as its own process:

    from botkit.telegram import Front, Settings, Shown, Texts, button_rows, esc

    def render_nudge(message, view):
        return Shown(esc(message["text"]))

    Front(Settings(api_url="http://127.0.0.1:8000/api/bot", token=..., allowed_user_ids={1, 2}, group_id=-100123),
          renderers={"nudge": render_nudge}, texts=Texts(hello="Hello.")).run()
"""
from botkit.telegram.clients import AppApi, AppDown, Telegram
from botkit.telegram.front import (
    DEFAULT_RENDERERS, UPLOADS, Front, Settings, Shown, Texts, View, action_key, apply_key, button_rows, choice_key,
    key, option_label, quiet_http_log, reject_key, render_answer, render_card, render_change, render_error, render_text,
    undo_key,
)
from botkit.telegram.layout import FOLD_OVER, MONO_WIDTH, TEXT_LIMIT, chunks, columns, esc, plain_text, quote, rich

__all__ = [
    "DEFAULT_RENDERERS", "FOLD_OVER", "MONO_WIDTH", "TEXT_LIMIT", "UPLOADS", "AppApi", "AppDown", "Front", "Settings",
    "Shown", "Telegram", "Texts", "View", "action_key", "apply_key", "button_rows", "choice_key", "chunks", "columns",
    "esc", "key", "option_label", "plain_text", "quiet_http_log", "quote", "reject_key", "render_answer", "render_card",
    "render_change", "render_error", "render_text", "rich", "undo_key",
]
