"""One reply's tools: the app's own, plus the kit's `make_change` and `show_choices` (SPEC.md §4).

Every runner reaches them through `call_tool`, which checks the arguments against the tool's schema and answers
`There is no tool called X.` for anything else. Each app tool's `doing` words go into the live log first, and what
it returns is kept for the write-up if the reply is stopped.
"""
from __future__ import annotations

import ast
import json
import logging
import threading
from typing import TYPE_CHECKING, Any

from jsonschema import Draft202012Validator

from botkit import words
from botkit.app import ToolContext
from botkit.runners.base import ToolResult, ToolSpec

if TYPE_CHECKING:
    from botkit.bot import Bot

logger = logging.getLogger("botkit")

WORK_RESULT_CHARS = 6000
MAX_CHOICES = 10
KIT_TOOLS = ("make_change", "show_choices")

_MAKE_CHANGE = (
    "Make a change the person asked for. A change of a kind marked card is shown to the person on a card: the app "
    "works out exactly what would change and shows it, and nothing happens until they press Apply. A change marked "
    "immediate is made at once and shown with an Undo button. If the app cannot make the change as given, the result "
    "says why: correct it and call again, or ask the person. You can make several changes in one reply. "
    "The changes the app can make:\n"
)
_SHOW_CHOICES = (
    "Put the things you are asking about under your reply as buttons, so the person can tap the one they mean. "
    "Your reply text asks the question."
)


def model_kinds(bot: "Bot") -> list[str]:
    """The kinds of change the model may make; the others only the app offers."""
    return [name for name, kind in bot.changes.items() if kind.for_model]


def make_change_spec(bot: "Bot") -> ToolSpec:
    lines = []
    for kind in (bot.changes[name] for name in model_kinds(bot)):
        line = f"- {kind.name} ({kind.mode}): {kind.signature}"
        if kind.describe:
            line += f"\n  {kind.describe}"
        lines.append(line)
    return ToolSpec("make_change", _MAKE_CHANGE + "\n".join(lines), {
        "type": "object",
        "properties": {
            "kind": {"type": "string", "enum": model_kinds(bot), "description": "The name of the change."},
            "summary": {"type": "string", "pattern": r"\S",
                        "description": "One plain sentence saying what will change, shown at the top of the card."},
            "args": {"type": "object", "description": "Its arguments, with ids you looked up."},
            "note": {"type": ["string", "null"],
                     "description": "One short sentence, only if something would surprise the person."},
            "replaces": {"type": "array", "items": {"type": "integer"}, "description": (
                "Ids of earlier cards this one corrects or takes the place of; they are withdrawn. "
                "Other cards stay as they are.")},
        },
        "required": ["kind", "summary", "args"],
        "additionalProperties": False,
    })


def show_choices_spec() -> ToolSpec:
    return ToolSpec("show_choices", _SHOW_CHOICES, {
        "type": "object",
        "properties": {"ids": {"type": "array", "minItems": 1, "maxItems": MAX_CHOICES,
                               "items": {"type": ["integer", "string"]},
                               "description": "The ids of the things to choose between."}},
        "required": ["ids"],
        "additionalProperties": False,
    })


def tool_specs(bot: "Bot") -> list[ToolSpec]:
    specs = [ToolSpec(t.name, t.description, t.input_schema) for t in bot.tools.values()]
    if model_kinds(bot):
        specs.append(make_change_spec(bot))
    if bot.describe_choice is not None:
        specs.append(show_choices_spec())
    return specs


def _path(error) -> str:
    return ".".join(str(p) for p in error.absolute_path)


def _problem_lines(error) -> list[str]:
    """One schema error as the kit words it (the same words in both packages): "path: what is wrong"."""
    path, where = _path(error), _path(error) or "(arguments)"
    kind, wanted = error.validator, error.validator_value
    if kind == "type":
        return [f"{where}: should be {' or '.join(wanted if isinstance(wanted, list) else [wanted])}"]
    if kind == "enum":
        return [f"{where}: should be one of {', '.join(json.dumps(o, ensure_ascii=False) for o in wanted)}"]
    if kind == "minLength":
        return [f"{where}: is too short"]
    if kind == "maxLength":
        return [f"{where}: is too long"]
    if kind == "pattern":
        return [f"{where}: does not match {wanted}"]
    if kind == "minimum":
        return [f"{where}: should be at least {wanted}"]
    if kind == "maximum":
        return [f"{where}: should be at most {wanted}"]
    if kind == "minItems":
        return [f"{where}: should have at least {wanted} items"]
    if kind == "maxItems":
        return [f"{where}: should have at most {wanted} items"]
    if kind == "required":
        name = ast.literal_eval(error.message.rsplit(" is a required property", 1)[0])
        return [f"{path + '.' if path else ''}{name}: is required"]
    if kind == "additionalProperties" and wanted is False:
        known = error.schema.get("properties", {})
        return [f"{path + '.' if path else ''}{name}: is not expected" for name in error.instance if name not in known]
    return [f"{where}: {error.message}"]


def _position(error, args: Any) -> list[int]:
    """Where an error sits in the arguments, as the order its keys were given in (what the problems are listed by)."""
    where, node = [], args
    for step in error.absolute_path:
        keys = list(node) if isinstance(node, dict) else range(len(node))
        where.append(list(keys).index(step))
        node = node[step]
    return where


def _problems(validator: Draft202012Validator, args: Any) -> str | None:
    """What does not fit, one line per problem, in the order the arguments were given (the same order in both packages)."""
    found = []
    for error in validator.iter_errors(args):
        position = _position(error, args)
        if error.validator == "additionalProperties" and error.validator_value is False:
            keys = list(error.instance)
            lines = [(position + [keys.index(name)], line) for name, line in zip(
                [k for k in keys if k not in error.schema.get("properties", {})], _problem_lines(error))]
        else:
            lines = [(position, line) for line in _problem_lines(error)]
        found.extend(lines)
    if not found:
        return None
    found.sort(key=lambda item: item[0])
    return "Those arguments don't fit: " + "; ".join(line for _, line in found)


class Toolbox:
    """One reply's tools and everything they have found and made so far."""

    def __init__(self, bot: "Bot", channel: str, conversation_id: int, message_id: int, page: str = "") -> None:
        self.bot = bot
        self.channel, self.conversation_id, self.message_id = channel, conversation_id, message_id
        self.page = page
        self.specs = tool_specs(bot)
        self._validators = {s.name: Draft202012Validator(s.input_schema) for s in self.specs}
        self._lock = threading.Lock()  # one tool call at a time, as the app's tools expect
        self.work: list[dict] = []  # each lookup and what it found, in order
        self.cards: list[int] = []  # ids of cards made in this reply
        self.changes: list[int] = []  # ids of immediate changes made in this reply
        self.choices: list[dict] = []
        self.state: dict = {}  # one reply's scratch space for the app's tools
        self.attached: dict = {}  # added to the payload of the answer the reply ends in
        self._closers: list = []

    def on_close(self, fn) -> None:
        self._closers.append(fn)

    def attach(self, **payload) -> None:
        self.attached.update(payload)

    def close(self) -> None:
        """The reply's run has ended: whatever the app's tools opened for it is closed, newest first."""
        while self._closers:
            fn = self._closers.pop()
            try:
                fn()
            except Exception:
                logger.exception("[bot] closing what a tool opened failed")

    def step(self, text: str) -> None:
        self.bot.service.add_step(self.message_id, text)

    def found(self, label: str, text: str) -> None:
        self.work.append({"looked_up": label, "found": str(text)[:WORK_RESULT_CHARS]})

    def context(self) -> ToolContext:
        return ToolContext(self.channel, self.conversation_id, self.message_id, self.bot.now(), self.step, self.found,
                           self.state, self.on_close, self.attach, self.page)

    def call_tool(self, name: str, args: dict) -> ToolResult:
        with self._lock:
            if name not in self._validators:
                return ToolResult(f"There is no tool called {name}.", True)
            problem = _problems(self._validators[name], args if args is not None else {})
            if problem:
                return ToolResult(problem, True)
            try:
                if name == "make_change":
                    return self._make_change(args)
                if name == "show_choices":
                    return self._show_choices(args)
                return self._run_app_tool(name, args)
            except Exception:
                logger.exception("[bot] tool %s failed", name)
                return ToolResult("That tool failed, so there is nothing from it. Say so plainly rather than guess.", True)

    def _run_app_tool(self, name: str, args: dict) -> ToolResult:
        tool = self.bot.tools[name]
        step = words.plain_step(args.get("doing", ""), tool.step)
        self.step(step)
        try:
            out = tool.run(args, self.context())
        except Exception:
            logger.exception("[bot] tool %s failed", name)
            self.found(step, "This lookup failed.")
            return ToolResult("This lookup failed, so there is nothing from it. Say so plainly rather than guess.", True)
        text, is_error = out if isinstance(out, tuple) else (out, False)
        if not isinstance(text, str):
            text = json.dumps(text, ensure_ascii=False, default=str)
        self.found(step, text)
        return ToolResult(text, bool(is_error))

    def _make_change(self, args: dict) -> ToolResult:
        kind = self.bot.changes[args["kind"]]
        if kind.mode == "card":
            self.step(words.plain_step(f"Preparing a card: {args['summary']}", "Preparing a card"))
            card_id, problem = self.bot.service.changes.make_card(self, kind, args)
            if problem:
                self.step(words.CORRECTING)
                return ToolResult(words.CARD_REFUSED.format(reason=problem), True)
            self.cards.append(card_id)
            return ToolResult(words.CARD_SHOWN)
        self.step(words.plain_step(f"Making a change: {args['summary']}", "Making a change"))
        change_id, problem = self.bot.service.changes.make_immediate(self, kind, args)
        if problem:
            self.step(words.CORRECTING)
            return ToolResult(words.CHANGE_REFUSED.format(reason=problem), True)
        self.changes.append(change_id)
        self.work.append({"changed": args["summary"], "made": True})
        return ToolResult(words.CHANGE_DONE)

    def _show_choices(self, args: dict) -> ToolResult:
        options = []
        for choice_id in dict.fromkeys(args["ids"]):
            described = self.bot.describe_choice(choice_id)
            if not described:
                return ToolResult(f"There is nothing with id {choice_id} to choose.", True)
            options.append({"id": choice_id, "label": described.get("label", ""), "detail": described.get("detail", "")})
        self.choices = options
        return ToolResult("The choices will be shown as buttons under your reply.")
