"""The runners (SPEC.md §3). Each is built from a RunnerConfig: `ClaudeCliRunner(config)` and so on.

Loaded on first use, so importing `botkit.runners.base` (as botkit.mcp does) never pulls in the runners themselves.
"""
import importlib

_RUNNERS = {
    "ClaudeCliRunner": "botkit.runners.claude_cli",
    "ClaudeApiRunner": "botkit.runners.claude_api",
    "CodexCliRunner": "botkit.runners.codex_cli",
    "OpenAiApiRunner": "botkit.runners.openai_api",
}

__all__ = list(_RUNNERS)


def __getattr__(name: str):
    if name in _RUNNERS:
        return getattr(importlib.import_module(_RUNNERS[name]), name)
    raise AttributeError(name)
