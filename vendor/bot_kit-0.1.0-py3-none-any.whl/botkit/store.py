"""The kit's own SQLite file (SPEC.md §8): conversations, messages, cards and changes.

A fresh connection per call, so the worker thread, the HTTP threads and the runners' tool threads never share
one. Writes that must hold together go through `write()`, which takes the write lock up front.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterator

SCHEMA_VERSION = "1"
IN_FLIGHT = ("queued", "running", "waiting", "stopping")
RESTARTED = "The app restarted while this was being applied. Check whether it took effect before applying again."
RESTARTED_UNDO = "The app restarted while this was being undone. Check whether it took effect before undoing again."

_SCHEMA = """
CREATE TABLE IF NOT EXISTS bot_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bot_conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, channel TEXT NOT NULL,
  runner TEXT, model TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bot_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id INTEGER NOT NULL REFERENCES bot_conversations(id),
  channel TEXT NOT NULL, role TEXT NOT NULL, kind TEXT NOT NULL, text TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'done', reply_to INTEGER, payload TEXT, steps TEXT, delivered TEXT,
  attachment BLOB, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_bot_messages_channel ON bot_messages(channel, id);
CREATE INDEX IF NOT EXISTS ix_bot_messages_status ON bot_messages(status);
CREATE TABLE IF NOT EXISTS bot_cards (
  id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER NOT NULL REFERENCES bot_messages(id),
  conversation_id INTEGER NOT NULL, channel TEXT NOT NULL, kind TEXT NOT NULL, summary TEXT NOT NULL,
  note TEXT, args TEXT NOT NULL, preview TEXT NOT NULL, version TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open', result TEXT, error TEXT, created_at TEXT NOT NULL, settled_at TEXT);
CREATE TABLE IF NOT EXISTS bot_changes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INTEGER NOT NULL REFERENCES bot_messages(id),
  conversation_id INTEGER NOT NULL, channel TEXT NOT NULL, kind TEXT NOT NULL, summary TEXT NOT NULL,
  args TEXT NOT NULL, lines TEXT NOT NULL, undo TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'done', error TEXT, created_at TEXT NOT NULL, settled_at TEXT);
"""

_JSON_COLUMNS = {"payload", "steps", "delivered", "args", "preview", "result", "lines", "undo"}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)


def row_dict(row: sqlite3.Row | None) -> dict | None:
    """A row with its JSON columns read back."""
    if row is None:
        return None
    out = dict(row)
    for key in _JSON_COLUMNS & out.keys():
        out[key] = json.loads(out[key]) if out[key] is not None else None
    return out


class Store:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript(_SCHEMA)
            db.execute("INSERT OR IGNORE INTO bot_meta (key, value) VALUES ('schema_version', ?)", (SCHEMA_VERSION,))

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        """Autocommit: each statement stands alone unless it runs inside `write()`."""
        db = sqlite3.connect(self.path, timeout=5, isolation_level=None, check_same_thread=False)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout = 5000")
        db.execute("PRAGMA foreign_keys = ON")
        try:
            yield db
        finally:
            db.close()

    @contextmanager
    def write(self) -> Iterator[sqlite3.Connection]:
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                yield db
            except BaseException:
                db.execute("ROLLBACK")
                raise
            db.execute("COMMIT")

    def recover(self) -> int:
        """After a restart: half-done replies go back in line, half-done applies and undos are marked failed.
        Returns how many messages are queued."""
        with self.write() as db:
            db.execute("UPDATE bot_messages SET status = 'queued' WHERE status IN ('running', 'waiting', 'stopping')")
            db.execute("UPDATE bot_cards SET status = 'failed', error = ?, settled_at = ? WHERE status = 'applying'",
                       (RESTARTED, now_iso()))
            db.execute("UPDATE bot_changes SET status = 'failed', error = ?, settled_at = ? WHERE status = 'undoing'",
                       (RESTARTED_UNDO, now_iso()))
            return db.execute("SELECT COUNT(*) FROM bot_messages WHERE status = 'queued'").fetchone()[0]

    # ---- Conversations ------------------------------------------------------------------------

    def current_conversation(self, channel: str, defaults: Callable[[], tuple[str | None, str | None]]) -> dict:
        """The channel's conversation since its last New chat, started on first use on `defaults()` runner and model."""
        query = "SELECT * FROM bot_conversations WHERE channel = ? ORDER BY id DESC LIMIT 1"
        with self.connect() as db:
            row = db.execute(query, (channel,)).fetchone()
        if row is not None:
            return dict(row)
        runner, model = defaults()
        with self.write() as db:
            row = db.execute(query, (channel,)).fetchone()
            if row is None:
                db.execute("INSERT INTO bot_conversations (channel, runner, model, created_at) VALUES (?, ?, ?, ?)",
                           (channel, runner, model, now_iso()))
                row = db.execute("SELECT * FROM bot_conversations WHERE id = last_insert_rowid()").fetchone()
            return dict(row)

    def current_conversation_id(self, db: sqlite3.Connection, channel: str) -> int:
        row = db.execute("SELECT MAX(id) FROM bot_conversations WHERE channel = ?", (channel,)).fetchone()
        return row[0] or 0

    # ---- Messages -----------------------------------------------------------------------------

    def insert_message(self, db: sqlite3.Connection, *, conversation_id: int, channel: str, role: str, kind: str,
                       text: str = "", status: str = "done", reply_to: int | None = None,
                       payload: dict | None = None, attachment: bytes | None = None) -> int:
        cursor = db.execute(
            "INSERT INTO bot_messages (conversation_id, channel, role, kind, text, status, reply_to, payload, steps,"
            " attachment, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?)",
            (conversation_id, channel, role, kind, text, status, reply_to, dumps(payload or {}), attachment, now_iso()),
        )
        return cursor.lastrowid

    def message(self, message_id: int, db: sqlite3.Connection | None = None) -> dict | None:
        if db is not None:
            return row_dict(db.execute("SELECT * FROM bot_messages WHERE id = ?", (message_id,)).fetchone())
        with self.connect() as fresh:
            return self.message(message_id, fresh)

    def merge_payload(self, db: sqlite3.Connection, message_id: int, **values) -> None:
        """Add keys to a message's payload. One already shown by a push front is marked to be shown again."""
        row = self.message(message_id, db)
        if row is None:
            return
        payload = {**(row["payload"] or {}), **values}
        if row["delivered"] is not None:
            payload["refresh"] = True
        db.execute("UPDATE bot_messages SET payload = ? WHERE id = ?", (dumps(payload), message_id))

    def mark_shown_again(self, db: sqlite3.Connection, message_id: int) -> None:
        row = self.message(message_id, db)
        if row is not None and row["delivered"] is not None:
            self.merge_payload(db, message_id)

    def add_step(self, message_id: int, step: str) -> None:
        with self.write() as db:
            row = db.execute("SELECT steps FROM bot_messages WHERE id = ?", (message_id,)).fetchone()
            if row is not None:
                steps = [*json.loads(row["steps"] or "[]"), step]
                db.execute("UPDATE bot_messages SET steps = ? WHERE id = ?", (dumps(steps), message_id))

    # ---- Cards and changes --------------------------------------------------------------------

    def card(self, card_id: int, db: sqlite3.Connection | None = None) -> dict | None:
        if db is not None:
            return row_dict(db.execute("SELECT * FROM bot_cards WHERE id = ?", (card_id,)).fetchone())
        with self.connect() as fresh:
            return self.card(card_id, fresh)

    def change(self, change_id: int, db: sqlite3.Connection | None = None) -> dict | None:
        if db is not None:
            return row_dict(db.execute("SELECT * FROM bot_changes WHERE id = ?", (change_id,)).fetchone())
        with self.connect() as fresh:
            return self.change(change_id, fresh)

    def settle_card(self, card_id: int, from_statuses: tuple[str, ...], **values) -> bool:
        """One guarded update: only a card still in one of `from_statuses` moves. Returns whether it did."""
        return self._settle("bot_cards", card_id, from_statuses, values)

    def settle_change(self, change_id: int, from_statuses: tuple[str, ...], **values) -> bool:
        return self._settle("bot_changes", change_id, from_statuses, values)

    def _settle(self, table: str, row_id: int, from_statuses: tuple[str, ...], values: dict,
                extra_where: str = "", extra_args: tuple = ()) -> bool:
        if values.get("status") not in (None, "applying", "undoing", "open"):
            values.setdefault("settled_at", now_iso())
        columns = ", ".join(f"{key} = ?" for key in values)
        args = [dumps(v) if key in _JSON_COLUMNS and v is not None else v for key, v in values.items()]
        marks = ", ".join("?" for _ in from_statuses)
        with self.write() as db:
            cursor = db.execute(
                f"UPDATE {table} SET {columns} WHERE id = ? AND status IN ({marks}){extra_where}",
                (*args, row_id, *from_statuses, *extra_args),
            )
            if cursor.rowcount:
                message_id = db.execute(f"SELECT message_id FROM {table} WHERE id = ?", (row_id,)).fetchone()[0]
                self.mark_shown_again(db, message_id)
            return cursor.rowcount > 0

    def start_applying(self, card_id: int, version: str) -> bool:
        """`open|failed → applying`, only for the version that was on screen."""
        return self._settle("bot_cards", card_id, ("open", "failed"), {"status": "applying", "error": None},
                            " AND version = ?", (version,))
