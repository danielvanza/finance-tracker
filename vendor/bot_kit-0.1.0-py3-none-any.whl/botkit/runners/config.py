"""Where each runner finds what it needs (SPEC.md §3.3). Every field is optional; a runner with nothing set up
reports that honestly in its status instead of failing later."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _env(name: str) -> str | None:
    value = os.getenv(name)
    return value or None


@dataclass
class RunnerConfig:
    # Claude Code CLI, on this machine's login, in a sandbox
    claude_bin: str | None = None  # default: `claude` on PATH
    claude_credentials: Path = field(default_factory=lambda: Path.home() / ".claude" / ".credentials.json")
    claude_home: Path | None = None  # private folder for the sandbox's home; required for claude-cli
    claude_models: list[str] = field(default_factory=lambda: ["sonnet", "opus", "haiku"])

    # Claude API
    anthropic_api_key: str | None = field(default_factory=lambda: _env("ANTHROPIC_API_KEY"))
    anthropic_models: list[str] = field(default_factory=lambda: ["claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5"])
    anthropic_base_url: str = "https://api.anthropic.com"

    # Codex CLI, on this machine's login, in a sandbox
    codex_bin: str | None = None  # default: `codex` on PATH
    codex_credentials: Path = field(default_factory=lambda: Path.home() / ".codex" / "auth.json")
    codex_home: Path | None = None  # private folder for the sandbox's CODEX_HOME; required for codex-cli

    # OpenAI API
    openai_api_key: str | None = field(default_factory=lambda: _env("OPENAI_API_KEY"))
    openai_models: list[str] = field(default_factory=list)  # empty: discovered from /v1/models when a key is set
    openai_base_url: str = "https://api.openai.com"

    # What a new conversation starts on
    default_runner: str = "claude-cli"
    default_model: str | None = None  # default: the runner's first model

    # Test mode only: register the `script` runner (SPEC.md §12)
    script_runner: bool = False
