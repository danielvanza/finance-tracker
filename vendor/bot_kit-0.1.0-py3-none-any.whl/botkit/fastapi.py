"""The HTTP API (SPEC.md §9) as a FastAPI router. The app mounts it behind its own sign-in:

    app.include_router(bot_router(bot), prefix="/api/bot", dependencies=[Depends(signed_in)])

Only the shapes live here; every rule (Apply once, stale cards, Undo once, no fallback) is in the service.
"""
from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, File, Form, HTTPException, Query, Response, UploadFile
from pydantic import BaseModel, Field

from botkit.bot import Bot
from botkit.changes import NotFound
from botkit.service import Unacceptable

_CHANNEL = dict(min_length=1, max_length=40, pattern=r"^[A-Za-z0-9_.-]+$")
Channel = Annotated[str, Field(**_CHANNEL)]
ChannelQuery = Annotated[str, Query(**_CHANNEL)]
ChannelForm = Annotated[str, Form(**_CHANNEL)]


class MessageIn(BaseModel):
    channel: Channel
    text: str | None = None
    choice_id: int | str | None = None
    seen_message_id: int | None = None  # the newest message on this person's screen
    page: str | None = Field(default=None, max_length=4000)  # what the person has on screen, as the UI names it


class ChannelIn(BaseModel):
    channel: Channel


class RunnerIn(BaseModel):
    channel: Channel
    runner: str
    model: str | None = None


class ApplyIn(BaseModel):
    version: str  # the card's version that was on screen when it was tapped


class ActionIn(BaseModel):
    value: Any = None


class DeliveredIn(BaseModel):
    ids: list[Any]


def _call(fn, *args):
    try:
        return fn(*args)
    except NotFound:
        raise HTTPException(404, "Not found") from None
    except Unacceptable as e:
        raise HTTPException(422, str(e)) from None


def _image_type(data: bytes) -> str:
    if data.startswith(b"\x89PNG"):
        return "image/png"
    if data.startswith(b"\xff\xd8"):
        return "image/jpeg"
    if data.lstrip().startswith((b"<svg", b"<?xml")):
        return "image/svg+xml"
    return "application/octet-stream"


def bot_router(bot: Bot) -> APIRouter:
    service = bot.service
    router = APIRouter()

    @router.get("/conversation")
    def get_conversation(channel: ChannelQuery = "bubble"):
        return service.conversation(channel)

    @router.post("/messages", status_code=202)
    def post_message(body: MessageIn):
        return _call(service.submit, body.channel, body.text, body.choice_id, body.seen_message_id, body.page)

    @router.post("/uploads/{kind}", status_code=202)
    def post_upload(kind: str, channel: ChannelForm, file: UploadFile = File(...), caption: str = Form("")):
        return _call(service.upload, channel, kind, file.file.read(), caption, file.filename or "")

    @router.post("/stop")
    def post_stop(body: ChannelIn):
        return {"stopped": service.stop(body.channel)}

    @router.post("/new")
    def post_new(body: ChannelIn):
        return {"conversation": service.new_chat(body.channel)}

    @router.get("/runners")
    def get_runners(channel: ChannelQuery = "bubble"):
        return service.runners(channel)

    @router.post("/runner")
    def post_runner(body: RunnerIn):
        return _call(service.select_runner, body.channel, body.runner, body.model)

    @router.get("/starters")
    def get_starters(channel: ChannelQuery = "bubble", page: str = ""):
        return {"starters": service.starters(channel, page)}

    @router.post("/cards/{card_id}/apply")
    def apply_card(card_id: int, body: ApplyIn):
        return _call(service.apply_card, card_id, body.version)

    @router.post("/cards/{card_id}/reject")
    def reject_card(card_id: int):
        return _call(service.reject_card, card_id)

    @router.post("/changes/{change_id}/undo")
    def undo_change(change_id: int):
        return _call(service.undo_change, change_id)

    @router.post("/messages/{message_id}/actions/{action}")
    def run_action(message_id: int, action: str, body: ActionIn | None = None):
        return _call(service.run_action, message_id, action, body.value if body else None)

    @router.get("/outbox")
    def get_outbox(channel: ChannelQuery = "bubble"):
        return service.outbox(channel)

    @router.post("/messages/{message_id}/delivered")
    def post_delivered(message_id: int, body: DeliveredIn):
        _call(service.mark_delivered, message_id, body.ids)
        return {}

    @router.get("/messages/{message_id}/image")
    def get_image(message_id: int, theme: str = "day"):
        if theme not in ("day", "night"):
            raise HTTPException(422, "theme is day or night")
        data = _call(service.image, message_id, theme)
        return Response(data, media_type=_image_type(data), headers={"Cache-Control": "private, max-age=86400"})

    return router
