"""The Telegram front (SPEC.md §11): its own process, one group, the allowed people in it, and the app reached only
through the kit's HTTP API (§9). Taken from household-finance's telegram_bot.py; what is the app's own (how its
message kinds and cards look, its words) comes in through `renderers`, `texts` and `log_lead`.

It long-polls Telegram for messages and button presses, sends what people write to `/messages` and what they upload
to `/uploads/{kind}`, and in a second thread pumps `/outbox`: new replies are sent, changed ones edited in place, a
live log with Stop is kept up to date for each reply being worked on, and every message shown is marked
`/delivered` with the Telegram message ids that show it. Unasked messages keep the quiet hours on the server.
Message contents are never logged.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable

import httpx

from botkit.telegram.clients import POLL_SECONDS, TELEGRAM_FAILED, AppApi, AppDown, Telegram, decode_value, encode_value
from botkit.telegram.layout import TEXT_LIMIT, chunks, esc, plain_text, rich

logger = logging.getLogger("botkit.telegram")

WAIT_NOTE_AFTER_SECONDS = 3
LOG_STEPS = 40
TYPING_EVERY_SECONDS = 4
CALLBACK_BYTES = 64  # Telegram's limit for a button's data
STOP_WORDS = {"stop", "/stop"}
# What a person can send that the front cannot read (besides uploads the app does not take).
UNREADABLE = ("sticker", "video", "video_note", "animation", "location", "venue", "contact", "poll", "dice")
STOP_DATA = "s:0"


@dataclass
class Texts:
    """Everything the front says in its own words. An app replaces the ones that should name it."""
    app_down: str = "The app can't be reached right now, so nothing changed. Try again in a moment."
    app_unsure: str = ("The app stopped answering, so I can't tell whether that went through. "
                       "Check the app before trying again.")
    app_refused: str = "The app didn't accept that, so nothing changed."
    app_lost: str = ("The app stopped while working on that. It will carry on when it is back, "
                     "and the answer will come here.")
    waiting: str = "Waiting for my turn. Your message is saved and will be answered as soon as I am free."
    new_chat: str = "Started a new chat. I won't draw on what we said before."
    # Telegram sends /start whenever the bot is opened afresh, so it must never cost the conversation.
    hello: str = "Hello. Ask me anything. We carry on where we left off; send /new to start a new chat."
    group_only: str = "I only work in our shared group. Write to me there."
    nothing_to_stop: str = "Nothing is being worked on right now."
    image_lost: str = "The picture could not be sent this time."
    not_understood: str = "I can't read that kind of message. Say it in words."
    working: str = "Working on it…"
    stopping: str = "Stopping…"
    stop: str = "Stop"
    try_again: str = "Try again"
    not_done: str = "That didn't go through, and nothing changed."
    # Per upload kind: said when Telegram would not hand the file over.
    lost: dict[str, str] = field(default_factory=lambda: {
        "file": "That file could not be used because Telegram would not hand it over. Nothing changed.",
        "photo": "That photo could not be used because Telegram would not hand it over. Nothing changed.",
        "voice": "That voice note could not be used because Telegram would not hand it over. Nothing changed.",
    })
    lost_other: str = "That could not be used because Telegram would not hand it over. Nothing changed."
    # Per upload kind: said as soon as such an upload is taken. A kind with a notice gets no live log.
    notices: dict[str, str] = field(default_factory=dict)


@dataclass
class Settings:
    api_url: str  # where the kit's HTTP API is mounted, e.g. http://127.0.0.1:18600/api/chat
    token: str
    allowed_user_ids: set[int]
    group_id: int | None  # None: answer nobody, and log the id of a group one of the allowed people writes in
    telegram_api: str = "https://api.telegram.org"
    channel: str = "telegram"


# Telegram field of an incoming message → (the app's upload kind, the file name sent when Telegram gives none).
UPLOADS = {
    "document": ("file", "file"),
    "voice": ("voice", "voice.ogg"),
    "audio": ("voice", "voice.ogg"),
    "photo": ("photo", "photo.jpg"),
}


@dataclass
class Shown:
    """One message as Telegram shows it. `text` is Telegram HTML with everything in it escaped (`esc`, `rich`);
    `keys` are rows of inline buttons, made with the key helpers below; `image` sends the app's picture of the message
    (`GET /messages/{id}/image`) as a photo after the words; `ahead` is HTML sent once as its own message before it
    (it is not edited later)."""
    text: str
    keys: list[list[dict]] | None = None
    image: bool = False
    ahead: str | None = None


# ---- Buttons ----------------------------------------------------------------------------------------------------
# callback data: a:{card}:{version} apply · r:{card} reject · u:{change} undo · c:{choice id} choose ·
# b:{message}:{action}[:{json value}] a message's button (§7) · s:0 Stop · t:{n} a long one, kept in memory.

def key(label: str, data: str) -> dict:
    return {"text": label, "callback_data": data}


def apply_key(card: dict, label: str | None = None) -> dict:
    return key(label or card["apply_label"], f"a:{card['id']}:{card['version']}")


def reject_key(card: dict, label: str | None = None) -> dict:
    return key(label or card["reject_label"], f"r:{card['id']}")


def undo_key(change: dict, label: str | None = None) -> dict:
    return key(label or change.get("undo_label") or "Undo", f"u:{change['id']}")


def choice_key(choice_id, label: str) -> dict:
    return key(label, f"c:{choice_id}")


def action_key(message_id: int, button: dict) -> dict:
    data = f"b:{message_id}:{button['action']}"
    if button.get("value") is not None:
        data += ":" + encode_value(button["value"])
    return key(button["label"], data)


def button_rows(message: dict, buttons: list[dict] | None = None) -> list[list[dict]]:
    """A message's buttons (§7; a card's when it is a card), one per row. Disabled ones are left out."""
    if buttons is None:
        buttons = (message.get("card") or {}).get("buttons") or message.get("buttons") or []
    return [[action_key(message["id"], b)] for b in buttons if not b.get("disabled")]


# ---- What a renderer is given -----------------------------------------------------------------------------------

class View:
    """What a renderer may want besides the message: the person's message it answers (`asked()`), and whether it is
    the first reply to that message (`first_reply()`). Both are looked up only when asked for."""

    def __init__(self, front: "Front", message: dict | None, asked_id: int | None, lookup: "_Lookup"):
        self.front = front
        self.message = message
        self._asked_id = asked_id
        self._lookup = lookup

    @property
    def channel(self) -> str:
        return self.front.settings.channel

    def asked(self) -> dict | None:
        return self._lookup.message(self._asked_id) if self._asked_id else None

    def first_reply(self) -> bool:
        if not self.message or not self._asked_id:
            return False
        return not any(m["role"] == "assistant" and m.get("reply_to") == self._asked_id and m["id"] < self.message["id"]
                       for m in self._lookup.messages())


class _Lookup:
    """The conversation, read once per round when a renderer needs it. A person's message, once it has words, keeps
    them (a voice note's are set once heard), so those are remembered across rounds."""

    def __init__(self, front: "Front"):
        self._front = front
        self._messages: list[dict] | None = None

    def messages(self) -> list[dict]:
        if self._messages is None:
            self._messages = self._front.api.conversation()["messages"]
            for m in self._messages:
                if m["role"] == "user" and m["text"]:
                    self._front._known[m["id"]] = m
        return self._messages

    def message(self, message_id: int) -> dict | None:
        known = self._front._known.get(message_id)
        if known is not None:
            return known
        return next((m for m in self.messages() if m["id"] == message_id), None)


Renderer = Callable[[dict, View], "Shown | None"]


# ---- Default layouts: what any app's messages look like unless it gives its own --------------------------------

def render_text(message: dict, view: View) -> Shown:
    return Shown(esc(message["text"]), button_rows(message) or None)


def render_error(message: dict, view: View) -> Shown:
    return Shown(esc(message["text"]))


def option_label(option: dict) -> str:
    return " · ".join(str(part) for part in (option.get("label"), option.get("detail")) if part)


def render_answer(message: dict, view: View, choice_label: Callable[[dict], str] = option_label) -> Shown:
    """The model's words; with choices (`payload.options`), each as a line and a button; with a picture, the picture
    after the words."""
    payload = message.get("payload") or {}
    options = payload.get("options") or []
    if options:
        lines = [message["text"], "", *[f"• {choice_label(o)}" for o in options]]
        keys = [[choice_key(o["id"], choice_label(o)[:60])] for o in options]
        return Shown(esc("\n".join(lines)), keys + button_rows(message), image=bool(payload.get("image")))
    return Shown(rich(message["text"]), button_rows(message) or None, image=bool(payload.get("image")))


def render_card(message: dict, view: View) -> Shown:
    """A card (§6): the model's words, the heading, what will change, and Apply / Not this; then its result."""
    card = message["card"]
    status = card["status"]
    extra = button_rows(message)
    if status == "applied":
        return Shown("\n".join(["<b>Applied.</b>", *map(esc, card["lines"])]), extra or None)
    if status == "rejected":
        return Shown("Not applied. Nothing changed.")
    if status == "superseded":
        return Shown("Replaced by a newer suggestion. Nothing changed.")
    texts = view.front.texts
    if status == "failed":
        return Shown(f"{esc(texts.not_done)}\n\n{esc(card['error'] or '')}", [[apply_key(card, texts.try_again)]])
    head = [rich(card["says"]), ""] if card.get("says") else []
    if card.get("heading"):
        head.append(f"<b>{esc(card['heading'])}</b>")
    tail = [esc(card["note"])] if card.get("note") else []
    return Shown("\n".join([*head, *map(esc, card["lines"]), *tail]),
                 [[apply_key(card), reject_key(card)], *extra])


def render_change(message: dict, view: View) -> Shown:
    """An immediate change (§6), with Undo while it stands."""
    change = message["change"]
    lines = [esc(change["summary"]), *map(esc, change["lines"])]
    if change["status"] == "undone":
        return Shown("\n".join(["<b>Undone.</b>", *lines]))
    if change["status"] == "failed":
        return Shown("\n".join([*lines, "", esc(change["error"] or "")]), [[undo_key(change, view.front.texts.try_again)]])
    return Shown("\n".join(lines), [[undo_key(change)]])


DEFAULT_RENDERERS: dict[str, Renderer] = {
    "answer": render_answer, "error": render_error, "card": render_card, "change": render_change,
}


# ---- The front ----------------------------------------------------------------------------------------------------

class Front:
    """One Telegram group in front of one app.

    renderers: {kind: fn(message, view) -> Shown | None} for the app's own kinds, and to replace the defaults for
      `answer`, `error`, `card` (the message carries `card`) and `change`. None: the message is not shown.
    texts: the front's words (Texts). log_lead(item, view) -> str | None: a plain line above a live log (the item is
      an `in_flight` entry; `view.asked()` is the person's message being worked on).
    uploads: which Telegram fields go to which `/uploads/{kind}` (UPLOADS by default; leave out what the app does not
      take). callback_alias(data, front) -> str | None: turns button data the front does not know (e.g. from an
      earlier version of the bot) into data it does.
    """

    def __init__(self, settings: Settings, *, renderers: dict[str, Renderer] | None = None, texts: Texts | None = None,
                 log_lead: Callable[[dict, View], str | None] | None = None,
                 uploads: dict[str, tuple[str, str]] | None = None,
                 callback_alias: Callable[[str, "Front"], str | None] | None = None,
                 telegram: Telegram | None = None, api: AppApi | None = None):
        self.settings = settings
        self.texts = texts or Texts()
        self.renderers = {**DEFAULT_RENDERERS, **(renderers or {})}
        self.log_lead = log_lead
        self.uploads = dict(UPLOADS if uploads is None else uploads)
        self.callback_alias = callback_alias
        self.telegram = telegram or Telegram(settings.token, settings.telegram_api)
        self.api = api or AppApi(settings.api_url, settings.channel, self.texts)
        self.allowed = set(settings.allowed_user_ids)
        self.group = settings.group_id
        self._known: dict[int, dict] = {}
        self._told_waiting: set[int] = set()
        self._logs: dict[int, dict] = {}  # message id -> its log in Telegram: message_id, text, item
        self._in_flight: list[dict] = []
        self._told_lost = False
        self._last_typing = 0.0
        self._groups_seen: set[int] = set()
        self._long_data: dict[str, str] = {}
        self._wake = threading.Event()

    # ---- Who may talk -------------------------------------------------------------------------------------------

    def is_allowed(self, sender: dict | None, chat: dict | None) -> bool:
        """One of the allowed people, writing in the group."""
        return bool(
            sender and chat and self.group is not None and sender.get("id") in self.allowed
            and chat.get("id") == self.group and chat.get("type") in ("group", "supergroup")
        )

    def _elsewhere(self, sender: dict | None, chat: dict | None) -> None:
        """Someone wrote outside the group. One of the allowed people, in private, is pointed to the group; a group
        that is not set up is only noted in the log, so its id can be found. Everything else: silence."""
        if not sender or not chat or sender.get("id") not in self.allowed:
            return
        if chat.get("type") == "private" and chat.get("id") == sender.get("id"):
            self._safely(lambda _: self.telegram.call("sendMessage", chat_id=chat["id"], text=self.texts.group_only),
                         None)
        elif chat.get("type") in ("group", "supergroup") and chat.get("id") not in self._groups_seen:
            self._groups_seen.add(chat["id"])
            logger.info("one of the allowed people wrote in group %s, which is not the group set for this bot",
                        chat["id"])

    # ---- Sending ------------------------------------------------------------------------------------------------

    def _fit(self, keys: list[list[dict]] | None) -> list[list[dict]] | None:
        """Button data longer than Telegram takes is kept here and the button carries a short token instead."""
        if not keys:
            return keys
        fitted = []
        for row in keys:
            out = []
            for k in row:
                data = k["callback_data"]
                if len(data.encode()) > CALLBACK_BYTES:
                    token = f"t:{len(self._long_data) + 1}"
                    self._long_data[token] = data
                    k = {**k, "callback_data": token}
                out.append({**k, "text": k["text"][:64] or " "})
            fitted.append(out)
        return fitted

    def _laid_out(self, method: str, params: dict):
        """Send or edit a message with its layout; if Telegram cannot read the layout, as plain text."""
        try:
            return self.telegram.call(method, **params, parse_mode="HTML")
        except RuntimeError as e:
            if "parse entities" not in str(e):
                raise
            logger.warning("Telegram could not read a message's layout, so it went as plain text")
            return self.telegram.call(method, **{**params, "text": plain_text(params["text"])})

    def _send(self, chunk: str, keys: list | None) -> int:
        params = {"chat_id": self.group, "text": chunk}
        if keys:
            params["reply_markup"] = {"inline_keyboard": self._fit(keys)}
        return self._laid_out("sendMessage", params)["message_id"]

    def say(self, text: str, keys: list | None = None, laid_out: bool = False) -> list[int]:
        """Send text, in several messages if long. Buttons go on the last one. `laid_out` text is already Telegram's
        HTML; anything else is plain and shown as typed."""
        pieces = chunks(text if laid_out else esc(text))
        return [self._send(piece, keys if i == len(pieces) - 1 else None) for i, piece in enumerate(pieces)]

    def edit(self, message_id: int, text: str, keys: list | None) -> None:
        """Replace a message with this HTML."""
        params = {"chat_id": self.group, "message_id": message_id, "text": text[:TEXT_LIMIT],
                  "reply_markup": {"inline_keyboard": self._fit(keys) or []}}
        try:
            self._laid_out("editMessageText", params)
        except RuntimeError:
            logger.info("could not edit a message; it was probably already up to date")

    def _show(self, text: str, keys: list | None, shown: list[int], keep_extra: bool = False) -> list[int]:
        """Show a message, replacing the Telegram messages that already show it. `keep_extra`: the ones after the
        text (a picture) stay as they are."""
        pieces = chunks(text)
        ids = []
        for i, piece in enumerate(pieces):
            last = keys if i == len(pieces) - 1 else None
            if i < len(shown):
                self.edit(shown[i], piece, last)
                ids.append(shown[i])
            else:
                ids.append(self._send(piece, last))
        extra = shown[len(pieces):]
        if keep_extra:
            return ids + extra
        for old in extra:
            try:
                self.telegram.call("deleteMessage", chat_id=self.group, message_id=old)
            except TELEGRAM_FAILED:
                logger.info("could not delete an old part of a message")
        return ids

    def _send_image(self, message_id: int) -> list[int]:
        """The picture beside the words. The words are already out, so a failure here must not resend them."""
        try:
            return [self.telegram.send_photo(self.group, self.api.image(message_id))["message_id"]]
        except (AppDown, *TELEGRAM_FAILED):
            logger.warning("a picture could not be sent")
        try:
            return self.say(self.texts.image_lost)
        except TELEGRAM_FAILED:
            return []

    # ---- Messages from the app ----------------------------------------------------------------------------------

    def render(self, message: dict, lookup: _Lookup | None = None) -> Shown | None:
        kind = "card" if message.get("card") else "change" if message.get("change") else message["kind"]
        renderer = self.renderers.get(kind) or render_text
        return renderer(message, View(self, message, message.get("reply_to"), lookup or _Lookup(self)))

    def show_reply(self, reply: dict, lookup: _Lookup | None = None) -> list[int]:
        """A message nobody has been shown yet: sent, and the ids that show it returned."""
        shown = self.render(reply, lookup)
        if shown is None:
            return []
        if shown.ahead:
            self.say(shown.ahead, laid_out=True)
        ids = self.say(shown.text, shown.keys, laid_out=True)
        if shown.image:
            ids += self._send_image(reply["id"])
        return ids

    def show_again(self, message: dict, shown_ids: list[int], lookup: _Lookup | None = None) -> list[int]:
        """A message already shown, brought up to date in place."""
        shown = self.render(message, lookup)
        if shown is None:
            return shown_ids
        return self._show(shown.text, shown.keys, shown_ids, keep_extra=shown.image)

    @staticmethod
    def _settling(message: dict) -> bool:
        """A card or change between two states: shown once it lands."""
        return (message.get("card") or {}).get("status") == "applying" \
            or (message.get("change") or {}).get("status") == "undoing"

    def _updated(self, message: dict, tapped: int | None) -> None:
        """A message an action came back with: edited in place when it changed, and marked as shown."""
        payload = message.get("payload") or {}
        if (message.get("delivered") is not None and not payload.get("refresh")) or self._settling(message):
            return
        shown = message.get("delivered")
        shown = list(shown) if isinstance(shown, list) and shown else ([tapped] if tapped else [])
        self.api.delivered(message["id"], self.show_again(message, shown))

    def pump_once(self) -> None:
        """Show every reply not shown yet, bring changed ones up to date, keep the live logs, and say so when a
        message is waiting its turn."""
        box = self.api.outbox()
        self._told_lost = False
        self._in_flight = box["in_flight"]
        lookup = _Lookup(self)
        # The log goes before the reply comes, so the chat never shows both.
        self._update_logs(lookup)
        for reply in box["replies"]:
            self.api.delivered(reply["id"], self.show_reply(reply, lookup))
        for changed in box.get("edits", []):
            if self._settling(changed):
                continue
            shown = changed.get("delivered")
            self.api.delivered(changed["id"], self.show_again(changed, list(shown) if isinstance(shown, list) else [],
                                                              lookup))
        for item in self._in_flight:
            late = item["status"] == "queued" and item["age_seconds"] >= WAIT_NOTE_AFTER_SECONDS
            if (item["status"] == "waiting" or late) and item["id"] not in self._told_waiting:
                self._told_waiting.add(item["id"])
                self.say(self.texts.waiting)
        if self._in_flight and time.monotonic() - self._last_typing > TYPING_EVERY_SECONDS:
            self._last_typing = time.monotonic()
            self.telegram.call("sendChatAction", chat_id=self.group, action="typing")

    def _render_log(self, item: dict, lookup: _Lookup, status: str | None = None) -> tuple[str, list | None]:
        """The live log of one reply: one message, edited as the steps come in, with Stop. It is taken away when the
        reply is there."""
        status = status or item["status"]
        steps = item.get("steps") or []
        lead = self.log_lead(item, View(self, None, item["id"], lookup)) if self.log_lead else None
        shown = steps[-LOG_STEPS:]
        lines = [*([lead] if lead else []), self.texts.stopping if status == "stopping" else self.texts.working,
                 *(["…"] if len(steps) > len(shown) else []), *[f"• {step}" for step in shown]]
        keys = None if status == "stopping" else [[key(self.texts.stop, STOP_DATA)]]
        return esc("\n".join(lines)), keys

    def _update_logs(self, lookup: _Lookup) -> None:
        """One message per reply being worked on, kept up to date, and taken away once the reply is done."""
        working = {item["id"]: item for item in self._in_flight if item.get("kind", "text") not in self.texts.notices}
        for item_id, item in working.items():
            if item["status"] not in ("running", "stopping") and item_id not in self._logs:
                continue
            log = self._logs.get(item_id)
            text, keys = self._render_log(item, lookup)
            if log is None:
                log = self._logs[item_id] = {"message_id": self._send(text, keys), "text": text}
            elif log["text"] != text:
                self.edit(log["message_id"], text, keys)
                log["text"] = text
            log["item"] = item
        for item_id in [i for i in self._logs if i not in working]:
            log = self._logs.pop(item_id)
            try:
                self.telegram.call("deleteMessage", chat_id=self.group, message_id=log["message_id"])
            except TELEGRAM_FAILED:
                logger.info("could not remove a finished log")

    def pump_forever(self) -> None:
        while True:
            try:
                self.pump_once()
            except AppDown:
                if self._in_flight and not self._told_lost:
                    self._told_lost = True
                    self._safely(lambda _: self.say(self.texts.app_lost), None)
            except (RuntimeError, httpx.HTTPError) as e:
                logger.warning("delivering replies failed: %s", type(e).__name__)
            except Exception:
                logger.exception("delivering replies failed")
            self._wake.wait(1)
            self._wake.clear()

    # ---- Messages from people -----------------------------------------------------------------------------------

    def _fetch(self, file_id: str, lost: str) -> bytes | None:
        try:
            return self.telegram.download(file_id)
        except TELEGRAM_FAILED:
            self.say(lost)
            return None

    def _upload(self, message: dict, field_name: str) -> None:
        kind, default_name = self.uploads[field_name]
        item = message[field_name]
        if field_name == "photo":  # several sizes of one picture: the biggest
            item = max(item, key=lambda size: size.get("file_size") or size.get("width", 0))
        content = self._fetch(item["file_id"], self.texts.lost.get(kind, self.texts.lost_other))
        if content is None:
            return
        notice = self.texts.notices.get(kind)
        if notice:
            self._safely(lambda _: self.say(notice), None)  # the upload matters more than the notice
        self.api.upload(kind, item.get("file_name") or default_name, content, message.get("caption") or "")
        self._wake.set()

    def on_message(self, message: dict) -> None:
        if not self.is_allowed(message.get("from"), message.get("chat")):
            self._elsewhere(message.get("from"), message.get("chat"))
            return
        # In a group a command may carry the bot's name: /new@SomeBot.
        command = (message.get("text") or "").strip().lower().split("@")[0]
        upload = next((name for name in self.uploads if message.get(name)), None)
        try:
            if upload:
                self._upload(message, upload)
            elif command in STOP_WORDS:
                self._stop()
            elif command == "/new":
                self.api.new_chat()
                self.say(self.texts.new_chat)
            elif command == "/start":
                self.say(self.texts.hello)
            elif message.get("text"):
                self.api.send(message["text"])  # a typed yes or no is settled at once; the card shows it next round
                self._wake.set()
            elif any(message.get(kind) for kind in (*UNREADABLE, *UPLOADS)):
                self.say(self.texts.not_understood)
            # Anything else is Telegram's own business (someone joined, a message was pinned): no reply.
        except AppDown as e:
            self.say(e.message)

    def _stop(self) -> None:
        if not self.api.stop():
            self.say(self.texts.nothing_to_stop)
            return
        lookup = _Lookup(self)
        for log in list(self._logs.values()):  # said at once, not at the next look at the app
            if "item" not in log:
                continue
            text, _ = self._render_log(log["item"], lookup, status="stopping")
            if log["text"] != text:
                self.edit(log["message_id"], text, None)
                log["text"] = text

    def _acknowledge(self, query: dict) -> None:
        """Stop the button's spinner. A press that arrives late is still a press, so failing here is fine."""
        try:
            self.telegram.call("answerCallbackQuery", callback_query_id=query["id"])
        except TELEGRAM_FAILED:
            logger.info("too late to acknowledge a button press")

    def card_message(self, card_id: int) -> dict | None:
        """The message in this conversation that shows card `card_id`."""
        return next((m for m in self.api.conversation()["messages"] if (m.get("card") or {}).get("id") == card_id),
                    None)

    def on_callback(self, query: dict) -> None:
        self._acknowledge(query)
        if not self.is_allowed(query.get("from"), (query.get("message") or {}).get("chat")):
            return
        tapped = query["message"]["message_id"]
        data = query.get("data") or ""
        data = self._long_data.get(data, data)
        if data[:2] not in ("a:", "r:", "u:", "c:", "b:", "s:") and self.callback_alias is not None:
            try:
                data = self.callback_alias(data, self) or ""
            except AppDown as e:
                self.say(e.message)
                return
        action, _, rest = data.partition(":")
        if action == "s":
            try:
                self._stop()
            except AppDown as e:
                self.say(e.message)
            return
        raw_id, _, more = rest.partition(":")
        try:
            if action == "c":
                self.edit(tapped, esc(query["message"].get("text") or "…"), None)
                self.api.send(choice_id=int(raw_id) if raw_id.lstrip("-").isdigit() else raw_id)
                self._wake.set()
                return
            if not raw_id.isdigit():
                return
            item = int(raw_id)
            if action == "b":
                name, _, value = more.partition(":")
                self._updated(self.api.action(item, name, decode_value(value) if value else None), tapped)
                self._wake.set()  # the action may have said something new
            elif action == "a":
                self._updated(self.api.apply(item, more), tapped)
            elif action == "r":
                self._updated(self.api.reject(item), tapped)
            elif action == "u":
                self._updated(self.api.undo(item), tapped)
        except AppDown as e:
            if action in ("a", "r", "u"):
                text = e.message if e.unknown else f"{self.texts.not_done}\n\n{e.message}"
                self.edit(tapped, esc(text), [[key(self.texts.try_again, query.get("data") or data)]])
            else:
                self.say(e.message)

    # ---- Running ------------------------------------------------------------------------------------------------

    def run(self) -> None:
        if self.group is not None:
            threading.Thread(target=self.pump_forever, name="deliver", daemon=True).start()
        offset = None
        with ThreadPoolExecutor(max_workers=4) as pool:
            while True:
                try:
                    params = {"timeout": POLL_SECONDS, "allowed_updates": ["message", "callback_query"]}
                    if offset is not None:
                        params["offset"] = offset
                    updates = self.telegram.get_updates(**params)
                except httpx.TimeoutException:
                    continue
                except TELEGRAM_FAILED as e:
                    logger.warning("polling Telegram failed: %s", type(e).__name__)
                    time.sleep(3)
                    continue
                for update in updates:
                    offset = update["update_id"] + 1
                    if "message" in update:
                        pool.submit(self._safely, self.on_message, update["message"])
                    elif "callback_query" in update:
                        pool.submit(self._safely, self.on_callback, update["callback_query"])

    @staticmethod
    def _safely(handler, payload) -> None:
        try:
            handler(payload)
        except Exception:
            logger.exception("handling a Telegram update failed")


def quiet_http_log() -> None:
    """httpx logs every request URL, and Telegram's carry the bot token."""
    logging.getLogger("httpx").setLevel(logging.WARNING)
