"""What the model is given for one reply (SPEC.md §5.2), and for writing up what it found when stopped (§5.3)."""
from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from botkit import words

if TYPE_CHECKING:
    from botkit.bot import Bot

logger = logging.getLogger("botkit")

MAX_CONVERSATION_CHARS = 600_000  # a guard, not a window
MAX_WORK_CHARS = 60_000
MAX_CARD_ARGS = 1500
TOO_LONG = {"from": "app", "note": "The start of this conversation was too long to include."}


def default_entry(message: dict) -> dict | None:
    """How one stored message appears in <conversation> unless the app says otherwise."""
    payload = message.get("payload") or {}
    if message["role"] == "system":
        return None
    if message["role"] == "user":
        entry = {"from": "person", "text": message["text"]}
        if message["kind"] != "text":
            entry["sent_a"] = message["kind"]
        if payload.get("ended") == "stopped":
            entry["note"] = "they pressed Stop while you worked on this"
        return entry
    if message.get("card"):
        card = message["card"]
        shown = {"id": card["id"], "summary": card["summary"], "kind": card["kind"], "status": card["status"]}
        if "args" in card and len(json.dumps(card["args"], ensure_ascii=False, default=str)) <= MAX_CARD_ARGS:
            shown["args"] = card["args"]
        if card.get("error"):
            shown["error"] = card["error"]
        entry = {"from": "app", "card": shown}
        if card.get("says"):
            entry["you_said_with_it"] = card["says"]
        return entry
    if message.get("change"):
        change = message["change"]
        return {"from": "app", "change": {k: change[k] for k in ("id", "summary", "kind", "status")}}
    if message["kind"] == "error":
        return {"from": "app", "error": message["text"]}
    if message["kind"] == "answer":
        entry = {"from": "you", "text": message["text"]}
        options = payload.get("options")
        if options:
            entry["choices_shown"] = [f"{o['label']}, {o['detail']} (id {o['id']})" for o in options]
        return entry
    return {"from": "app", message["kind"]: message["text"]}


def entry_for(bot: "Bot", message: dict) -> dict | None:
    if bot.history_entry is not None:
        try:
            entry = bot.history_entry(message)
        except Exception:
            logger.exception("[bot] the app's history entry failed for message %s", message["id"])
            entry = None
        if entry is not None:
            return entry
    return default_entry(message)


def conversation_json(entries: list[dict]) -> str:
    text = json.dumps(entries, ensure_ascii=False, default=str)
    while len(text) > MAX_CONVERSATION_CHARS and len(entries) > 1:
        entries = [TOO_LONG, *entries[len(entries) // 4 + 1:]]
        text = json.dumps(entries, ensure_ascii=False, default=str)
    return text


def build(bot: "Bot", context: dict, history: list[dict], message: dict) -> str:
    entries = [e for e in (entry_for(bot, m) for m in history) if e]
    said = entry_for(bot, message) or {"from": "person", "text": message["text"]}
    return (
        f"<context>\n{json.dumps(context, ensure_ascii=False, default=str)}\n</context>\n\n"
        f"<conversation>\n{conversation_json(entries)}\n</conversation>\n\n"
        f"<new_message>\n{json.dumps(said, ensure_ascii=False, default=str)}\n</new_message>"
    )


def wrap_up(bot: "Bot", prompt: str, work: list[dict], ended: str) -> str:
    found = json.dumps(work, ensure_ascii=False, default=str)[:MAX_WORK_CHARS]
    why = words.STOPPED_BY_PERSON if ended == "stopped" else words.STOPPED_AT_LIMIT
    changed = words.SOME_CHANGED if any(w.get("made") for w in work) else words.NOTHING_CHANGED
    instruction = (bot.wrap_up or words.WRAP_UP).format(why=why, changed=changed)
    return f"{prompt}\n\n<work_so_far>\n{found}\n</work_so_far>\n\n{instruction}"
