"""The test runner (SPEC.md §12): only the model is fake. It reads directives from the new message and calls the
app's real tools through the same `call_tool` the real runners use.

    SCRIPT-TOOL name {json}   call a tool (several lines run in order)
    SCRIPT-SAY text           the final text (default: a summary of the tool results)
    SCRIPT-SLOW n             wait n seconds between steps, checking should_stop
    SCRIPT-FAIL kind          fail with that RunnerFailure kind before doing anything
    SCRIPT-FAIL-LATER kind    fail with that kind at this point, after the lines before it ran
    SCRIPT-CRASH              raise an unexpected error (not a RunnerFailure) at this point
    SCRIPT-ECHO               say the whole prompt the model was given (context, conversation, new message)
"""
from __future__ import annotations

import json
import time

from botkit.runners.base import Model, RunnerFailure, RunnerStatus, RunRequest, RunResult

FAILURE_KINDS = ("logged_out", "no_key", "missing", "rate_limited", "timeout", "stopped", "policy", "unsupported",
                 "error")


def new_message_text(prompt: str) -> str:
    """What the person said, from the prompt's <new_message> block."""
    start = prompt.rfind("<new_message>")
    end = prompt.rfind("</new_message>")
    if start < 0 or end < start:
        return prompt
    raw = prompt[start + len("<new_message>"):end].strip()
    try:
        said = json.loads(raw)
    except ValueError:
        return raw
    if isinstance(said, dict):
        return str(said.get("text") or "")
    return str(said)


class ScriptRunner:
    id = "script"
    label = "Test script"

    def __init__(self, config=None) -> None:
        self.config = config

    def status(self) -> RunnerStatus:
        return RunnerStatus(self.id, self.label, "ready", "Runs the directives in the message, for tests.",
                            [Model("script", "Script")], "script")

    def run(self, request: RunRequest) -> RunResult:
        deadline = time.monotonic() + request.timeout_seconds
        if not request.tools and "<work_so_far>" in request.prompt:
            found = request.prompt.split("<work_so_far>", 1)[1].split("</work_so_far>", 1)[0].strip()
            return RunResult(f"I stopped early, so this is partial. So far: {found[:300]}")
        lines = [line.strip() for line in new_message_text(request.prompt).splitlines()]
        for line in lines:
            if line.startswith("SCRIPT-FAIL") and not line.startswith("SCRIPT-FAIL-LATER"):
                kind = line.removeprefix("SCRIPT-FAIL").strip() or "error"
                raise RunnerFailure(kind if kind in FAILURE_KINDS else "error", f"The script asked to fail ({kind}).")

        delay, said, results = 0.0, [], []
        for line in lines:
            if line.startswith("SCRIPT-SLOW"):
                delay = float(line.removeprefix("SCRIPT-SLOW").strip() or 0)
            elif line.startswith("SCRIPT-TOOL"):
                self._wait(delay, request, deadline)
                name, _, raw = line.removeprefix("SCRIPT-TOOL").strip().partition(" ")
                try:
                    args = json.loads(raw) if raw.strip() else {}
                except ValueError as e:
                    raise RunnerFailure("error", f"The script's arguments for {name} are not JSON: {e}") from None
                result = request.call_tool(name, args)
                results.append((name, result))
            elif line.startswith("SCRIPT-SAY"):
                said.append(line.removeprefix("SCRIPT-SAY").strip())
            elif line.startswith("SCRIPT-ECHO"):
                said.append(request.prompt)
            elif line.startswith("SCRIPT-FAIL-LATER"):
                kind = line.removeprefix("SCRIPT-FAIL-LATER").strip() or "error"
                raise RunnerFailure(kind if kind in FAILURE_KINDS else "error", f"The script asked to fail ({kind}).")
            elif line.startswith("SCRIPT-CRASH"):
                raise RuntimeError("The script asked to crash.")
        self._wait(delay, request, deadline)
        if said:
            return RunResult("\n".join(said))
        if not results:
            return RunResult("The script ran no tools.")
        return RunResult("\n".join(
            f"- {name}{' (error)' if r.is_error else ''}: {' '.join(r.text.split())[:300]}" for name, r in results
        ))

    @staticmethod
    def _wait(seconds: float, request: RunRequest, deadline: float) -> None:
        until = time.monotonic() + seconds
        while True:
            if request.should_stop():
                raise RunnerFailure("stopped", "Stopped.")
            if time.monotonic() >= deadline:
                raise RunnerFailure("timeout", "The time limit was reached.")
            if time.monotonic() >= until:
                return
            time.sleep(0.1)
