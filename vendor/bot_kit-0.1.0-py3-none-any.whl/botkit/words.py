"""Everything the kit says in its own words, in one place. Taken from household-finance's chat."""
from __future__ import annotations

import re

MAX_STEP = 90

STOPPED_IN_LINE = "Stopped before I started on that. Nothing changed."
STOPPED_BEFORE = "Stopped. I had not found anything yet, so I have nothing to add, and nothing changed."
TIMED_OUT_BEFORE = ("That took longer than one reply may take, so I stopped early, before I had found anything. "
                    "Nothing changed.")
STOPPED_FALLBACK = "I stopped early, and could not write up what I had found. Nothing changed."
STOPPED_FALLBACK_CHANGED = "I stopped early, and could not write up what I had found."
PARTIAL = "I stopped early, so this is partial."
SAYS_STOPPED = ("stop", "time limit", "ran out of time", "cut short", "partial")
STEP_WRITING_UP = "Stopped. Writing up what I found so far"
STEP_STOPPED = "Stopped"

STALE_NOTE = "Something changed since this was shown, so nothing was applied. Check it again."
SOMETHING_WRONG = "Something went wrong on this side, so nothing changed."
EMPTY_REPLY = "{label}'s answer came back empty, so nothing changed. Try saying it another way."
WHICH_ONE = "Which one do you mean?"

CARD_SHOWN = "The card is shown. Nothing changes unless the person presses Apply."
CHANGE_DONE = "Done. The person sees it with an Undo button."
CARD_REFUSED = "No card was shown, because the app would not take this: {reason}"
CHANGE_REFUSED = "That was not done, because the app would not take it: {reason}"
CORRECTING = "The app would not take that as it was, so I am correcting it"

STOPPED_BY_PERSON = "The person pressed Stop while you were working on <new_message>."
STOPPED_AT_LIMIT = "You reached the time limit for one reply while working on <new_message>."
WRAP_UP = """<stopped>
{why} You cannot look anything else up or make changes now. In <work_so_far> is everything you looked up in this reply before that.
Reply to the person now: say plainly that you stopped early, then what you had found so far that answers them, with only what is in <work_so_far>. If it found nothing useful yet, say that. {changed}
</stopped>"""
NOTHING_CHANGED = "Nothing has changed."
SOME_CHANGED = "Only the changes in <work_so_far> marked as made have been made."

DEFAULT_LABELS = {"heading": "Proposed change", "apply": "Apply", "reject": "Not this", "rejected": "Not applied. Nothing changed."}
UNDO_LABEL = "Undo"

# A typed answer to the one card in front of the person (household-finance's word lists).
YES = {"yes", "y", "ja", "yep", "yeah", "ok", "okay", "oké", "apply", "confirm", "ja graag", "yes please", "doe maar"}
NO = {"no", "n", "nee", "nope", "not this", "cancel", "niet doen"}

REASONS = {
    "logged_out": "{label} is logged out on this machine, so it cannot answer until someone logs in again. Nothing changed.",
    "no_key": "{label} has no API key set up, so it cannot answer. Nothing changed.",
    "missing": "{label} is not installed on this machine, so it cannot answer. Nothing changed.",
    "rate_limited": "{label} has reached its usage limit, so it cannot answer until the limit resets. Nothing changed.",
    "unsupported": "{label} cannot read pictures, so it cannot answer this one. Nothing changed.",
    "policy": "{label} tried to use something it is not allowed to, so I stopped it. Nothing changed.",
    "error": "{label} could not be reached. Nothing changed.",
}
PARTLY_DONE = "What I had already done in this reply is shown above."


def partly_done(reason: str) -> str:
    """A failure after the reply already made a card or a change must not claim that nothing changed."""
    return reason.removesuffix("Nothing changed.").rstrip() + " " + PARTLY_DONE


API_LOGGED_OUT = "{label} refused its API key, so it cannot answer. Nothing changed."

_QUERY_WORDS = ("SELECT ", " FROM ", "WHERE ", "GROUP BY", "ORDER BY")
_QUERY_NAMES = ("_cents", "_eur", "_pct", "_count", "category_months", "month_totals", "spending table", "coverage table")
_QUERY_CLAUSES = (" where ", " group by ", " order by ", " join ", " limit ", "count(", "sum(", "avg(", "*")


def normalise(text: str) -> str:
    return re.sub(r"[\s.!]+", " ", text.lower()).strip()


def reads_like_a_query(prose: str) -> bool:
    lowered = f" {' '.join(prose.lower().split())} "
    if any(name in lowered for name in _QUERY_NAMES) or any(word in prose for word in _QUERY_WORDS):
        return True
    return "select " in lowered and " from " in lowered and any(clause in lowered for clause in _QUERY_CLAUSES)


def plain_step(doing: str, fallback: str) -> str:
    """What the live log says: the model's words if they are plain, never query text."""
    words = " ".join(str(doing or "").split())
    if not words or reads_like_a_query(words):
        return fallback
    return words if len(words) <= MAX_STEP else words[:MAX_STEP - 1] + "…"


def says_it_stopped(text: str) -> bool:
    return any(word in text.lower() for word in SAYS_STOPPED)
