"""SECURITY CRITICAL. The bubblewrap sandbox and private home both CLI runners run in (SPEC §3.4).

The machine's normal CLI configuration exposes private context, so a model never runs with it. Every CLI run gets:
  1. A private home holding nothing of the machine's but a symlink to the login token (never a copy; see
     `PrivateHome.link_credential` for what happens when a CLI replaces the link while refreshing the token).
  2. An environment built from an allowlist: nothing is inherited from the app's environment.
  3. A fresh, empty work directory, refused if it sits inside a repository or under CLAUDE.md / AGENTS.md.
  4. A bubblewrap container: / is a handful of read-only system dirs, /home is an empty tmpfs, and the private home,
     the work dir, the token and the CLI itself appear at neutral paths under /sandbox.
The runners add their own CLI flags on top (built-in tools off, no settings, only the app's MCP server).
Extracted from household-finance's categorizer/claude_cli.py and Roadmap Studio's providers/isolation.ts.
"""
from __future__ import annotations

import fcntl
import os
import shutil
import subprocess
import tempfile
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator

from botkit.runners.common import POLL

SANDBOX_ROOT = "/sandbox"
SANDBOX_HOME = "/sandbox/home"
SANDBOX_WORK = "/sandbox/work"
SANDBOX_CRED_DIR = "/sandbox/cred"
SANDBOX_BIN = "/sandbox/bin"

_HAZARDS = (".git", "CLAUDE.md", "AGENTS.md", ".claude", ".codex")


class SandboxRefused(Exception):
    """The sandbox could not be set up safely, so nothing was started."""


class Waited(Exception):
    """should_stop() said to stop while the run was still queued behind another one."""


def find_binary(name: str, override: str | None = None) -> str | None:
    """The real path of a CLI: the configured one, or `name` on PATH (plus ~/.local/bin)."""
    if override:
        found = shutil.which(override) or (override if os.access(override, os.X_OK) else None)
    else:
        path = os.pathsep.join([os.environ.get("PATH", ""), str(Path.home() / ".local" / "bin"), "/usr/local/bin", "/usr/bin"])
        found = shutil.which(name, path=path)
    return os.path.realpath(found) if found else None


def find_bwrap() -> str | None:
    return shutil.which("bwrap") or next((p for p in ("/usr/bin/bwrap", "/usr/local/bin/bwrap") if os.access(p, os.X_OK)), None)


def context_hazards(directory: Path) -> list[str]:
    """Anything up the tree from `directory` that would pull a repository or instructions into a CLI's context.

    The real home's own entries are not counted: bubblewrap replaces /home with an empty tmpfs, so they are not there.
    """
    found: list[str] = []
    real_home = Path.home().resolve()
    current = directory.resolve()
    while True:
        if current != real_home:
            found += [str(current / name) for name in _HAZARDS if os.path.lexists(current / name)]
        if current.parent == current:
            return found
        current = current.parent


@dataclass
class PrivateHome:
    """One CLI's private folder: `home/` (the sandbox's $HOME) and `runs/` (one empty work dir per run)."""

    provider: str  # "claude" | "codex": the name the CLI gets inside the sandbox
    base: Path
    credential_file: Path  # the real login token on the host
    credential_name: str  # its name inside the private home

    @property
    def home(self) -> Path:
        return self.base / "home"

    def prepare(self) -> None:
        for folder in (self.base, self.home, self.base / "runs"):
            folder.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.link_credential()

    def has_credential(self) -> bool:
        return self.credential_file.is_file()

    def link_credential(self) -> None:
        """Point the private home at the login token by a symlink, so no second copy exists.

        A CLI that refreshes its token by atomic rename replaces the link with a real file holding the newest token, and
        the original may then be stale, so that file is moved (not copied) back to the real location before re-linking.
        """
        link = self.home / self.credential_name
        target = f"{SANDBOX_CRED_DIR}/{self.credential_name}"
        if os.path.lexists(link) and not link.is_symlink():
            if self.credential_file.exists() and self.credential_file.stat().st_mtime < link.stat().st_mtime:
                os.replace(link, self.credential_file)
            else:
                link.unlink()
        if link.is_symlink() and os.readlink(link) != target:
            link.unlink()
        if not link.is_symlink():
            link.symlink_to(target)

    def refusal(self) -> str | None:
        """Why work_dir() would refuse every run here (it sits in a repository or under instructions), or None. Read only:
        it does not prepare the home or touch the credential link."""
        hazards = context_hazards(self.base / "runs")
        return f"the work dir sits under {', '.join(hazards)}; put the private home outside any repository" if hazards else None

    @contextmanager
    def work_dir(self) -> Iterator[Path]:
        """A fresh, empty work dir for one run, removed afterwards. Refused if it sits in a repository or under
        instructions a CLI would read."""
        self.prepare()
        work = Path(tempfile.mkdtemp(prefix="run-", dir=self.base / "runs"))
        try:
            hazards = context_hazards(work)
            if hazards:
                raise SandboxRefused(f"the work dir sits under {', '.join(hazards)}; put the private home outside any repository")
            yield work
        finally:
            shutil.rmtree(work, ignore_errors=True)

    @contextmanager
    def one_at_a_time(self, on_wait: Callable[[bool], None] | None, should_stop: Callable[[], bool]) -> Iterator[None]:
        """Runs share the private home (its account cache and the credential link), so only one runs at a time, also
        across processes (a lock file). While queued, on_wait(True) is called once, then on_wait(False) when this run
        starts; should_stop() is checked a few times a second and raises Waited."""
        self.prepare()
        waited = False
        # flock locks belong to an open file, so two threads of one process exclude each other as two processes do.
        fd = os.open(self.base / ".lock", os.O_RDWR | os.O_CREAT, 0o600)
        try:
            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if not waited:
                        waited = True
                        if on_wait:
                            on_wait(True)
                    if should_stop():
                        raise Waited("stopped while waiting")
                    time.sleep(POLL)
            if waited and on_wait:
                on_wait(False)
            yield
        finally:
            os.close(fd)  # releases the lock


def _node_root(script: str) -> str | None:
    """The Node prefix an npm-installed CLI lives in (the dir holding bin/node), walking up from the script."""
    current = Path(script).parent
    while current.parent != current:
        if (current / "bin" / "node").exists():
            return str(current)
        current = current.parent
    return None


def build_command(
    home: PrivateHome, work: Path, binary: str, args: list[str], env: dict[str, str], home_env: list[str],
    bwrap: str = "bwrap",
) -> tuple[list[str], dict[str, str]]:
    """The exact process to start and its complete environment. Pure, so it can be printed and checked."""
    real = os.path.realpath(binary)
    full_env = {
        "LANG": "C.UTF-8", "TERM": "dumb", "NO_COLOR": "1",
        **({"TZ": os.environ["TZ"]} if os.environ.get("TZ") else {}),
        **env,
        "HOME": SANDBOX_HOME,
    }
    for name in home_env:
        full_env[name] = SANDBOX_HOME
    command = [
        bwrap,
        "--unshare-pid", "--unshare-ipc", "--unshare-uts", "--unshare-cgroup-try",
        "--hostname", "sandbox", "--die-with-parent", "--new-session",
        "--ro-bind", "/usr", "/usr",
        "--ro-bind", "/bin", "/bin",
        "--ro-bind", "/lib", "/lib",
        "--ro-bind-try", "/lib64", "/lib64",
        "--ro-bind-try", "/etc/ssl", "/etc/ssl",
        "--ro-bind-try", "/etc/ca-certificates", "/etc/ca-certificates",
        "--ro-bind-try", "/etc/resolv.conf", "/etc/resolv.conf",
        "--ro-bind-try", "/etc/hosts", "/etc/hosts",
        "--ro-bind-try", "/etc/nsswitch.conf", "/etc/nsswitch.conf",
        "--ro-bind-try", "/etc/localtime", "/etc/localtime",
        "--proc", "/proc",
        "--dev", "/dev",
        "--tmpfs", "/tmp",
        "--tmpfs", "/home",
        "--tmpfs", "/root",
        "--dir", SANDBOX_ROOT,
        "--bind", str(home.home), SANDBOX_HOME,
        "--bind", str(work), SANDBOX_WORK,
        "--chdir", SANDBOX_WORK,
    ]
    # The token is bound at a neutral path so an in-place refresh still reaches the real file. Without one, the CLI
    # sees a dangling link and reports itself logged out.
    if home.has_credential():
        command += ["--dir", SANDBOX_CRED_DIR, "--bind", str(home.credential_file), f"{SANDBOX_CRED_DIR}/{home.credential_name}"]
    if real.endswith((".js", ".mjs", ".cjs")):
        # An npm-installed CLI (codex): mount its Node prefix (the runtime and global packages), read-only.
        root = _node_root(real)
        if root is None:
            raise SandboxRefused(f"could not find the Node runtime for {real}")
        command += ["--ro-bind", root, f"{SANDBOX_BIN}/node"]
        inner = [f"{SANDBOX_BIN}/node/bin/node", real.replace(root, f"{SANDBOX_BIN}/node", 1)]
        full_env["PATH"] = f"{SANDBOX_BIN}/node/bin:/usr/bin:/bin"
    else:
        command += ["--ro-bind", real, f"{SANDBOX_BIN}/{home.provider}"]
        inner = [f"{SANDBOX_BIN}/{home.provider}"]
        full_env["PATH"] = f"{SANDBOX_BIN}:/usr/bin:/bin"
    return [*command, "--", *inner, *args], full_env


@dataclass
class ProcessResult:
    code: int | None
    stdout: str
    stderr: str
    killed_for: str | None  # "timeout" | "stopped" | "policy" | None


def run_process(
    command: list[str], env: dict[str, str], cwd: Path, stdin: str, timeout: float,
    should_stop: Callable[[], bool] = lambda: False,
    on_line: Callable[[str, Callable[[str], None]], None] | None = None,
) -> ProcessResult:
    """Runs one sandboxed CLI to its end, feeding stdin and handing over stdout line by line. on_line may call
    kill(reason). should_stop() and the time limit are checked a few times a second; either kills the process."""
    process = subprocess.Popen(
        command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, cwd=cwd,
        text=True, encoding="utf-8", errors="replace", bufsize=1,
    )
    killed: list[str] = []
    out: list[str] = []
    err: list[str] = []

    def kill(reason: str) -> None:
        if killed:
            return
        killed.append(reason)
        try:
            process.terminate()
        except ProcessLookupError:
            pass

        def hard() -> None:
            try:
                process.wait(1.5)
            except subprocess.TimeoutExpired:
                process.kill()
        threading.Thread(target=hard, daemon=True).start()

    def feed() -> None:
        try:
            assert process.stdin is not None
            process.stdin.write(stdin)
            process.stdin.close()
        except (BrokenPipeError, OSError, ValueError):
            pass  # a CLI that exits early closes stdin

    def read_out() -> None:
        assert process.stdout is not None
        for line in process.stdout:
            out.append(line)
            if on_line and line.strip() and not killed:
                try:
                    on_line(line.rstrip("\n"), kill)
                except Exception as e:  # a bug in a watcher must end the run, not let it go on unwatched
                    kill(f"policy:watcher failed: {e}")

    def read_err() -> None:
        assert process.stderr is not None
        for line in process.stderr:
            if sum(map(len, err)) < 200_000:
                err.append(line)

    threads = [threading.Thread(target=f, daemon=True) for f in (feed, read_out, read_err)]
    for thread in threads:
        thread.start()
    deadline = time.monotonic() + timeout
    while process.poll() is None:
        try:
            process.wait(POLL)
        except subprocess.TimeoutExpired:
            pass
        if process.poll() is not None:
            break
        if should_stop():
            kill("stopped")
        elif time.monotonic() > deadline:
            kill("timeout")
    for thread in threads[1:]:
        thread.join(5)
    reason = killed[0] if killed else None
    return ProcessResult(process.returncode, "".join(out), "".join(err), reason)
