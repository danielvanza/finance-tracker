"""Cards and immediate changes (SPEC.md §1 rules 1–4, §6). These rules live here, below the HTTP API, so no UI can
get round them: a card only runs from Apply, Apply and Undo run once, and a stale card is shown again, not applied.
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import TYPE_CHECKING

from botkit import words
from botkit.app import Applied, ChangeContext, ChangeError, ChangeKind, Preview, Stale
from botkit.store import dumps, now_iso

if TYPE_CHECKING:
    from botkit.bot import Bot
    from botkit.toolbox import Toolbox

logger = logging.getLogger("botkit")


class NotFound(Exception):
    pass


def version_of(preview: dict) -> str:
    """Identifies what a card shows, so a tap can be matched to the version that was on screen."""
    return hashlib.sha256(json.dumps(preview, sort_keys=True, default=str).encode()).hexdigest()[:8]


def _same(a, b) -> bool:
    return json.dumps(a, sort_keys=True, default=str) == json.dumps(b, sort_keys=True, default=str)


def _preview(value) -> Preview:
    if not isinstance(value, Preview):
        raise TypeError(f"preview must return a Preview, not {type(value).__name__}")
    return value


class Changes:
    def __init__(self, bot: "Bot") -> None:
        self.bot = bot
        self.store = bot.store

    # ---- What the UI shows ----------------------------------------------------------------------

    def card_json(self, card: dict, message: dict) -> dict:
        kind = self.bot.changes.get(card["kind"])
        labels = {**words.DEFAULT_LABELS, **(kind.labels if kind else {})}
        preview = card["preview"] or {}
        payload = message.get("payload") or {}
        return {
            "id": card["id"], "status": card["status"], "kind": card["kind"], "summary": card["summary"],
            "says": payload.get("says"), "heading": labels["heading"], "apply_label": labels["apply"],
            "reject_label": labels["reject"], "rejected_text": labels["rejected"], "lines": preview.get("lines") or [], "note": card["note"],
            "error": card["error"], "version": card["version"], "result": card["result"], "data": preview.get("data"),
            "buttons": self._buttons(kind, card, message),
        }

    @staticmethod
    def _buttons(kind: ChangeKind | None, card: dict, message: dict) -> list[dict]:
        if kind is None or kind.buttons is None:
            return (message.get("payload") or {}).get("buttons") or []
        try:
            return list(kind.buttons(card, message) or [])
        except Exception:
            logger.exception("[bot] the buttons of card %s could not be worked out", card["id"])
            return []

    @staticmethod
    def change_json(change: dict) -> dict:
        return {
            "id": change["id"], "status": change["status"], "kind": change["kind"], "summary": change["summary"],
            "lines": change["lines"] or [], "error": change["error"], "undo_label": words.UNDO_LABEL,
        }

    # ---- Made by the model ----------------------------------------------------------------------

    def _context(self, toolbox: "Toolbox") -> ChangeContext:
        return ChangeContext(toolbox.channel, toolbox.conversation_id, toolbox.message_id, self.bot.now(),
                             page=toolbox.page)

    def make_card(self, toolbox: "Toolbox", kind: ChangeKind, args: dict) -> tuple[int | None, str | None]:
        """Show a card, or say why the app would not take it, for the model to put right."""
        try:
            preview = _preview(kind.preview(args["args"], self._context(toolbox))).as_json()
        except ChangeError as e:
            return None, e.reason
        except Exception:
            logger.exception("[bot] previewing %s failed", kind.name)
            return None, "the app could not work out what this would change"
        replaces = list(args.get("replaces") or [])
        note = args.get("note") or preview.get("note")
        with self.store.write() as db:
            if self.store.current_conversation_id(db, toolbox.channel) != toolbox.conversation_id:
                return None, "the conversation moved on, so this card was not shown"
            same = self._same_open(db, toolbox.conversation_id, kind.name, args["args"], preview, replaces)
            if same is not None:
                return None, (f"a card for exactly this change is already open (card {same}), so it was not "
                              "made a second time. Point the person to that card")
            if replaces:
                for replaced in replaces:  # a card already shown by a push front is shown again, withdrawn
                    withdrawn = db.execute(
                        "UPDATE bot_cards SET status = 'superseded', settled_at = ? WHERE id = ? AND channel = ? "
                        "AND status IN ('open', 'failed')", (now_iso(), replaced, toolbox.channel))
                    if withdrawn.rowcount:
                        old = self.store.card(replaced, db)
                        if old is not None:
                            self.store.mark_shown_again(db, old["message_id"])
            return self._insert_card(db, toolbox.conversation_id, toolbox.channel, kind.name, args["summary"], note,
                                     args["args"], preview, toolbox.message_id), None

    @staticmethod
    def _same_open(db, conversation_id: int, kind: str, args: dict, preview: dict, replaces=()) -> int | None:
        """The open card in this conversation that shows exactly this change, if there is one."""
        rows = db.execute(
            "SELECT id, args, preview FROM bot_cards WHERE conversation_id = ? AND status = 'open' AND kind = ?",
            (conversation_id, kind),
        ).fetchall()
        for row in rows:
            if row["id"] not in replaces and _same(json.loads(row["args"]), args) \
                    and _same(json.loads(row["preview"]), preview):
                return row["id"]
        return None

    def _insert_card(self, db, conversation_id: int, channel: str, kind: str, summary: str, note: str | None,
                     args: dict, preview: dict, reply_to: int | None) -> int:
        message_id = self.store.insert_message(
            db, conversation_id=conversation_id, channel=channel, role="assistant", kind="card", text=summary,
            reply_to=reply_to,
        )
        cursor = db.execute(
            "INSERT INTO bot_cards (message_id, conversation_id, channel, kind, summary, note, args, preview,"
            " version, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)",
            (message_id, conversation_id, channel, kind, summary, note, dumps(args), dumps(preview),
             version_of(preview), now_iso()),
        )
        return cursor.lastrowid

    def offer(self, channel: str, kind_name: str, summary: str, args: dict, reply_to: int | None,
              note: str | None) -> int:
        """A card the app offers itself (Bot.offer): previewed like one the model makes, and only run by Apply."""
        kind = self.bot.changes.get(kind_name)
        if kind is None or kind.mode != "card":
            raise ValueError(f"{kind_name} is not a card kind of this app")
        conversation = self.bot.service.conversation_row(channel)
        ctx = ChangeContext(channel, conversation["id"], reply_to, self.bot.now(),
                            page=self._page_of_message(reply_to))
        preview = _preview(kind.preview(args, ctx)).as_json()  # ChangeError goes to the caller
        with self.store.write() as db:
            conversation_id = self.store.current_conversation_id(db, channel)
            same = self._same_open(db, conversation_id, kind_name, args, preview)
            if same is not None:
                return same
            return self._insert_card(db, conversation_id, channel, kind_name, summary, note or preview.get("note"),
                                     args, preview, reply_to)

    def make_immediate(self, toolbox: "Toolbox", kind: ChangeKind, args: dict) -> tuple[int | None, str | None]:
        """Make the change at once and show it with Undo, or say why it was not made."""
        ctx = self._context(toolbox)
        with self.store.connect() as db:
            if self.store.current_conversation_id(db, toolbox.channel) != toolbox.conversation_id:
                return None, "the conversation moved on, so this was not done"
        try:
            preview = _preview(kind.preview(args["args"], ctx))
            applied = kind.apply(args["args"], preview, ctx)
        except ChangeError as e:
            return None, e.reason
        except Stale:
            return None, "what it would change moved while it was being made, so look it up again"
        except Exception:
            logger.exception("[bot] making %s failed", kind.name)
            return None, "the change could not be saved"
        applied = applied or Applied()
        lines = applied.lines if applied.lines is not None else preview.lines
        with self.store.write() as db:  # saved even if the conversation moved on meanwhile, so it can be undone
            message_id = self.store.insert_message(
                db, conversation_id=toolbox.conversation_id, channel=toolbox.channel, role="assistant",
                kind="change", text=args["summary"], reply_to=toolbox.message_id,
                payload={"result": applied.result} if applied.result is not None else None,
            )
            cursor = db.execute(
                "INSERT INTO bot_changes (message_id, conversation_id, channel, kind, summary, args, lines, undo,"
                " status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'done', ?)",
                (message_id, toolbox.conversation_id, toolbox.channel, kind.name, args["summary"],
                 dumps(args["args"]), dumps(list(lines)), dumps(applied.undo), now_iso()),
            )
            return cursor.lastrowid, None

    # ---- Pressed by the person ------------------------------------------------------------------

    def _card_or_404(self, card_id: int) -> dict:
        card = self.store.card(card_id)
        if card is None:
            raise NotFound()
        return card

    def apply_card(self, card_id: int, version: str | None = None) -> int:
        """A person's Apply. Runs the change once, however many times it is tapped. Returns the card's message id.

        A tap names the version it was made on; one on a version since replaced changes nothing. A typed yes has
        no version: the service has already vouched for which card it answers.
        """
        card = self._card_or_404(card_id)
        if card["status"] not in ("open", "failed") or version not in (None, card["version"]):
            return card["message_id"]
        kind = self.bot.changes.get(card["kind"])
        if kind is None or kind.mode != "card":
            self.store.settle_card(card_id, ("open", "failed"), status="failed",
                                   error="The app can no longer make this kind of change.")
            return card["message_id"]
        if not self.store.start_applying(card_id, card["version"]):
            return card["message_id"]
        ctx = ChangeContext(card["channel"], card["conversation_id"], self._asked_by(card["message_id"]), self.bot.now(),
                            card_id=card_id, page=self._page_of(card["message_id"]))
        try:
            applied = kind.apply(card["args"], Preview.from_json(card["preview"]), ctx) or Applied()
        except Stale as stale:
            fresh = _preview(stale.preview).as_json()
            self.store.settle_card(card_id, ("applying",), status="open", preview=fresh, version=version_of(fresh),
                                   note=words.STALE_NOTE, error=None)
        except ChangeError as e:
            self.store.settle_card(card_id, ("applying",), status="failed", error=e.reason)
        except Exception:
            logger.exception("[bot] applying card %s failed", card_id)
            self.store.settle_card(card_id, ("applying",), status="failed", error="The change could not be saved.")
        else:
            preview = card["preview"]
            if applied.lines is not None:
                preview = {**preview, "lines": list(applied.lines)}
            self.store.settle_card(card_id, ("applying",), status="applied", result=applied.result, preview=preview,
                                   error=None)
        return card["message_id"]

    def _asked_by(self, message_id: int) -> int | None:
        """The person's message a card or change answers."""
        return (self.store.message(message_id) or {}).get("reply_to")

    def _page_of(self, message_id: int) -> str:
        return self._page_of_message(self._asked_by(message_id))

    def _page_of_message(self, message_id: int | None) -> str:
        """The `page` a person's message was sent with."""
        if not message_id:
            return ""
        return str(((self.store.message(message_id) or {}).get("payload") or {}).get("page") or "")

    def reject_card(self, card_id: int) -> int:
        card = self._card_or_404(card_id)
        self.store.settle_card(card_id, ("open", "failed"), status="rejected")
        return card["message_id"]

    def undo_change(self, change_id: int) -> int:
        """A person's Undo. Restores once, however many times it is tapped."""
        change = self.store.change(change_id)
        if change is None:
            raise NotFound()
        kind = self.bot.changes.get(change["kind"])
        if kind is None or kind.undo is None:
            self.store.settle_change(change_id, ("done", "failed"), status="failed",
                                     error="The app cannot undo this kind of change.")
            return change["message_id"]
        if not self.store.settle_change(change_id, ("done", "failed"), status="undoing", error=None):
            return change["message_id"]
        ctx = ChangeContext(change["channel"], change["conversation_id"], self._asked_by(change["message_id"]),
                            self.bot.now(), change_id=change_id, page=self._page_of(change["message_id"]))
        try:
            said = kind.undo(change["undo"], ctx)
        except ChangeError as e:
            self.store.settle_change(change_id, ("undoing",), status="failed", error=e.reason)
        except Exception:
            logger.exception("[bot] undoing change %s failed", change_id)
            self.store.settle_change(change_id, ("undoing",), status="failed", error="The change could not be undone.")
        else:
            values = {"status": "undone"}
            if said:
                values["lines"] = [said]
            self.store.settle_change(change_id, ("undoing",), **values)
        return change["message_id"]
