"""The one object an app builds (SPEC.md §2). Everything else the kit does hangs off it."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator

from botkit.app import ActionContext, ChangeKind, Ctx, Incoming, Tool, ToModel
from botkit.runners.config import RunnerConfig
from botkit.runners.registry import Registry
from botkit.service import Service
from botkit.store import Store
from botkit.toolbox import KIT_TOOLS


class Bot:
    """An app's bot. Constructing it opens the store, puts half-done work back in line and starts the worker if
    anything is waiting; mount `botkit.fastapi.bot_router(bot)` to serve it.

    instructions(ctx) -> str (or a plain string); context(ctx) -> JSON object; starters(ctx) -> [{label, text}];
    history_entry(message) -> dict | None; handlers {kind: handler(Incoming) -> ToModel | None};
    actions {name: action(ActionContext)}; describe_choice(id) -> {label, detail} | None; choice_text(id) -> str;
    image(message, theme) -> bytes | None; quiet_hours(now) -> bool; clock() -> datetime;
    wrap_up: the write-up instruction, with {why} and optionally {changed};
    refresh(channel): brings the app's own messages up to date before a front reads the channel;
    typed_actions {action: {words}}: typed words that, like yes and no, answer the one card in front of the person,
    by running that action on the card's message.
    """

    def __init__(
        self,
        *,
        name: str,
        instructions: str | Callable[[Ctx], str],
        store_path: str | Path,
        tools: list[Tool] = (),
        changes: list[ChangeKind] = (),
        context: Callable[[Ctx], Any] | None = None,
        starters: Callable[[Ctx], list[dict]] | None = None,
        history_entry: Callable[[dict], dict | None] | None = None,
        handlers: dict[str, Callable[[Incoming], ToModel | None]] | None = None,
        actions: dict[str, Callable[[ActionContext], None]] | None = None,
        describe_choice: Callable[[Any], dict | None] | None = None,
        choice_text: Callable[[Any], str] | None = None,
        image: Callable[[dict, str], bytes | None] | None = None,
        runners: RunnerConfig | None = None,
        time_limit_seconds: float = 540,
        quiet_hours: Callable[[datetime], bool] | None = None,
        clock: Callable[[], datetime] | None = None,
        typed_answers: bool = True,
        wrap_up: str | None = None,
        refresh: Callable[[str], None] | None = None,
        typed_actions: dict[str, set[str]] | None = None,
    ) -> None:
        self.name = name
        self.instructions = instructions
        self.tools = {t.name: t for t in tools}
        self.changes = {c.name: c for c in changes}
        self.context = context
        self.starters = starters
        self.history_entry = history_entry
        self.handlers = dict(handlers or {})
        self.actions = dict(actions or {})
        self.describe_choice = describe_choice
        self.choice_text = choice_text
        self.image = image
        self.time_limit_seconds = time_limit_seconds
        self.quiet_hours = quiet_hours
        self.clock = clock
        self.typed_answers = typed_answers
        self.wrap_up = wrap_up
        self.refresh = refresh
        self.typed_actions = {action: set(said) for action, said in (typed_actions or {}).items()}
        self._check([t.name for t in tools])
        self.registry = Registry(runners or RunnerConfig())
        self.store = Store(store_path)
        self.service = Service(self)
        self.service.start()

    def _check(self, names: list[str]) -> None:
        """Mistakes in what the app hands over show at start-up, not in the middle of a reply."""
        if len(set(names)) != len(names) or set(names) & set(KIT_TOOLS):
            raise ValueError(f"tool names must be unique and not one of {KIT_TOOLS}")
        for tool in self.tools.values():
            Draft202012Validator.check_schema(tool.input_schema)
        for kind in self.changes.values():
            if kind.mode not in ("card", "immediate"):
                raise ValueError(f"change kind {kind.name}: mode must be card or immediate")
            if kind.mode == "immediate" and kind.undo is None:
                raise ValueError(f"change kind {kind.name}: an immediate change needs undo")
        missing = set(self.typed_actions) - set(self.actions)
        if missing:
            raise ValueError(f"typed_actions name actions the app does not have: {sorted(missing)}")

    def now(self) -> datetime:
        return self.clock() if self.clock is not None else datetime.now().astimezone()

    def post(self, channel: str, kind: str, text: str, payload: dict | None = None, *, unasked: bool = False,
             buttons: list[dict] | None = None, replace_unshown: bool = False) -> int:
        """Say something in a channel without being asked. Returns the message id."""
        return self.service.post(channel, kind, text, payload, unasked, buttons, replace_unshown)

    def offer(self, channel: str, kind: str, summary: str, args: dict, *, reply_to: int | None = None,
              note: str | None = None) -> int:
        """Show a card the app itself offers (no model involved), e.g. after an import. The same rules hold: it only
        runs from Apply. Raises ChangeError when the kind's preview refuses it. Returns the card id (the open one
        already showing exactly this change, if there is one)."""
        return self.service.changes.offer(channel, kind, summary, args, reply_to, note)
