"""The conversation: saving messages, working through them one at a time, Stop, New chat and a typed yes or no
(SPEC.md §5). Extracted from household-finance's assistant/service.py and assistant/brain.py.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from botkit import prompt as prompts
from botkit import words
from botkit.app import ActionContext, Ctx, Incoming, ToModel
from botkit.changes import Changes, NotFound
from botkit.runners.base import RunnerFailure, RunRequest, ToolResult
from botkit.store import IN_FLIGHT, dumps, now_iso, row_dict
from botkit.toolbox import Toolbox

if TYPE_CHECKING:
    from botkit.bot import Bot

logger = logging.getLogger("botkit")

HISTORY_LIMIT = 400
MIN_CALL_SECONDS = 5
WRAP_UP_SECONDS = 60
MAX_UPLOAD_BYTES = 20 * 1024 * 1024
MAX_TEXT = 20_000
KIT_KINDS = ("card", "change", "new_chat")


class Unacceptable(ValueError):
    """A request the HTTP layer answers with 422."""


class _Clock:
    """The time for one reply. Time spent waiting behind another run of the same login does not count."""

    def __init__(self, limit: float) -> None:
        self._deadline = time.monotonic() + limit
        self._waiting_since: float | None = None

    def on_wait(self, waiting: bool) -> None:
        if waiting and self._waiting_since is None:
            self._waiting_since = time.monotonic()
        elif not waiting and self._waiting_since is not None:
            self._deadline += time.monotonic() - self._waiting_since
            self._waiting_since = None

    def left(self) -> float:
        paused = time.monotonic() - self._waiting_since if self._waiting_since is not None else 0.0
        return self._deadline + paused - time.monotonic()


class Service:
    def __init__(self, bot: "Bot") -> None:
        self.bot = bot
        self.store = bot.store
        self.changes = Changes(bot)
        self._worker: threading.Thread | None = None
        self._worker_guard = threading.Lock()

    def start(self) -> None:
        """After a restart: anything half done goes back in line, and the worker picks it up."""
        if self.store.recover():
            self._ensure_worker()

    # ---- What the UI reads ----------------------------------------------------------------------

    def conversation_row(self, channel: str) -> dict:
        registry = self.bot.registry
        runner = registry.config.default_runner
        row = self.store.current_conversation(channel, lambda: (runner, registry.default_model(runner)))
        return self._conversation_json(row)

    def _conversation_json(self, row: dict) -> dict:
        registry = self.bot.registry
        runner = row["runner"] or registry.config.default_runner
        return {"id": row["id"], "channel": row["channel"], "runner": runner,
                "model": row["model"] or registry.default_model(runner)}

    def _messages_json(self, db, rows: list, with_args: bool = False) -> list[dict]:
        messages = [row_dict(r) for r in rows]
        ids = [m["id"] for m in messages]
        if not ids:
            return []
        marks = ", ".join("?" for _ in ids)
        cards = {c["message_id"]: c for c in map(row_dict, db.execute(
            f"SELECT * FROM bot_cards WHERE message_id IN ({marks})", ids).fetchall())}
        changes = {c["message_id"]: c for c in map(row_dict, db.execute(
            f"SELECT * FROM bot_changes WHERE message_id IN ({marks})", ids).fetchall())}
        out = []
        for m in messages:
            card, change = cards.get(m["id"]), changes.get(m["id"])
            payload = m["payload"] or {}
            item = {
                "id": m["id"], "conversation_id": m["conversation_id"], "channel": m["channel"], "role": m["role"],
                "kind": m["kind"], "text": m["text"], "status": m["status"], "reply_to": m["reply_to"],
                "payload": payload, "steps": m["steps"] or [], "created_at": m["created_at"],
                "delivered": m["delivered"],
                "card": self.changes.card_json(card, m) if card else None,
                "change": self.changes.change_json(change) if change else None,
                "buttons": [] if card else payload.get("buttons") or [],
                "ended": payload.get("ended"),
            }
            if with_args and card:
                item["card"]["args"] = card["args"]
            out.append(item)
        return out

    def message_json(self, message_id: int) -> dict:
        with self.store.connect() as db:
            rows = db.execute("SELECT * FROM bot_messages WHERE id = ?", (message_id,)).fetchall()
            if not rows:
                raise NotFound()
            return self._messages_json(db, rows)[0]

    def _refresh(self, channel: str) -> None:
        """The app brings its own messages up to date before a front reads them."""
        if self.bot.refresh is None:
            return
        try:
            self.bot.refresh(channel)
        except Exception:
            logger.exception("[bot] the app's refresh failed")

    def conversation(self, channel: str) -> dict:
        """The current conversation, from the last New chat on."""
        self._refresh(channel)
        conversation = self.conversation_row(channel)
        with self.store.connect() as db:
            rows = db.execute("SELECT * FROM bot_messages WHERE conversation_id = ? ORDER BY id DESC LIMIT ?",
                              (conversation["id"], HISTORY_LIMIT)).fetchall()
            messages = self._messages_json(db, list(reversed(rows)))
            busy = self._busy(db, conversation["id"])
        return {"conversation": conversation, "messages": messages, "busy": busy}

    @staticmethod
    def _busy(db, conversation_id: int) -> bool:
        """A reply is in flight in this conversation. One a New chat left behind winds down unseen."""
        marks = ", ".join("?" for _ in IN_FLIGHT)
        return db.execute(f"SELECT 1 FROM bot_messages WHERE conversation_id = ? AND role = 'user'"
                          f" AND status IN ({marks}) LIMIT 1", (conversation_id, *IN_FLIGHT)).fetchone() is not None

    def starters(self, channel: str, page: str = "") -> list[dict]:
        if self.bot.starters is None:
            return []
        conversation = self.conversation_row(channel)
        given = self.bot.starters(Ctx(channel, self.bot.now(), conversation["id"], page)) or []
        return [{"label": s["label"], "text": s["text"]} for s in given]

    # ---- Taking messages in ---------------------------------------------------------------------

    def _waiting_card(self, db, channel: str, conversation_id: int, seen_message_id: int | None) -> dict | None:
        """The one card a typed yes or no can mean: the only one still open that was made since the person last
        spoke, and actually shown."""
        last_said = db.execute("SELECT MAX(id) FROM bot_messages WHERE channel = ? AND role = 'user'",
                               (channel,)).fetchone()[0] or 0
        pending = db.execute("SELECT * FROM bot_cards WHERE conversation_id = ? AND status = 'open' AND message_id > ?",
                             (conversation_id, last_said)).fetchall()
        if len(pending) != 1 or pending[0]["note"] == words.STALE_NOTE:  # a yes can't say which version it meant
            return None
        card = row_dict(pending[0])
        card_message = self.store.message(card["message_id"], db)
        marks = ", ".join("?" for _ in IN_FLIGHT)
        working = db.execute(f"SELECT id FROM bot_messages WHERE channel = ? AND status IN ({marks})",
                             (channel, *IN_FLIGHT)).fetchall()
        # The reply that made the card may still be finishing its words; anything else in progress makes a yes unclear.
        if any(row["id"] != card_message["reply_to"] for row in working):
            return None
        shown = card_message["delivered"] is not None or (seen_message_id or 0) >= card["message_id"]
        return card if shown else None

    def submit(self, channel: str, text: str | None = None, choice_id: Any = None,
               seen_message_id: int | None = None, page: str | None = None) -> dict:
        """Save what the person said. A plain yes or no to the one card in front of them is settled here and now,
        and so are the app's typed actions (e.g. "show all")."""
        if choice_id is not None:
            text = self._choice_text(choice_id)
        text = (text or "").strip()
        if not text:
            raise Unacceptable("Say something first")
        if len(text) > MAX_TEXT:
            raise Unacceptable(f"That is too long: at most {MAX_TEXT} characters.")
        conversation = self.conversation_row(channel)
        answer = words.normalise(text)
        typed_action = None
        if answer not in words.YES | words.NO:
            typed_action = next((action for action, said in self.bot.typed_actions.items() if answer in said), None)
        settles = self.bot.typed_answers and (answer in words.YES | words.NO or typed_action is not None)
        payload = {}
        if choice_id is not None:
            payload["choice_id"] = choice_id
        if page:
            payload["page"] = page
        with self.store.write() as db:
            card = self._waiting_card(db, channel, conversation["id"], seen_message_id) if settles else None
            message_id = self.store.insert_message(
                db, conversation_id=conversation["id"], channel=channel, role="user", kind="text", text=text,
                status="done" if card else "queued", payload=payload or None,
            )
        saved = self.message_json(message_id)
        if card is None:
            self._ensure_worker()
        elif typed_action is not None:
            self.run_action(card["message_id"], typed_action)
        elif answer in words.YES:
            self.changes.apply_card(card["id"])
        else:
            self.changes.reject_card(card["id"])
        return saved if card is None else self.message_json(message_id)

    def _choice_text(self, choice_id: Any) -> str:
        described = self.bot.describe_choice(choice_id) if self.bot.describe_choice else None
        if not described:
            raise NotFound()
        if self.bot.choice_text is not None:
            return self.bot.choice_text(choice_id)
        return f"That one: {described.get('label', '')}, {described.get('detail', '')} (id {choice_id})"

    def upload(self, channel: str, kind: str, content: bytes, caption: str = "", filename: str = "") -> dict:
        """A file, photo or voice note, for the app's handler of that kind to deal with in the worker."""
        if kind not in self.bot.handlers or kind in ("text", *KIT_KINDS):
            raise NotFound()
        if len(content) > MAX_UPLOAD_BYTES:
            raise Unacceptable("That file is too large.")
        conversation = self.conversation_row(channel)
        with self.store.write() as db:
            message_id = self.store.insert_message(
                db, conversation_id=conversation["id"], channel=channel, role="user", kind=kind,
                text=caption.strip(), status="queued", payload={"filename": filename, "size": len(content)},
                attachment=content,
            )
        saved = self.message_json(message_id)
        self._ensure_worker()
        return saved

    def post(self, channel: str, kind: str, text: str, payload: dict | None = None, unasked: bool = False,
             buttons: list[dict] | None = None, replace_unshown: bool = False) -> int:
        """Say something without being asked. `unasked` messages wait out the quiet hours on push fronts.
        `replace_unshown` takes back earlier messages of this kind nobody has been shown yet, so a front that could
        not be reached for a while gets one message, not a row of them."""
        if kind in KIT_KINDS:
            raise ValueError(f"{kind} messages are made by the kit")
        conversation = self.conversation_row(channel)
        payload = dict(payload or {})
        if unasked:
            payload["unasked"] = True
        if buttons is not None:
            payload["buttons"] = buttons
        with self.store.write() as db:
            if replace_unshown:
                db.execute("DELETE FROM bot_messages WHERE channel = ? AND kind = ? AND role = 'assistant'"
                           " AND delivered IS NULL", (channel, kind))
            return self.store.insert_message(db, conversation_id=conversation["id"], channel=channel,
                                             role="assistant", kind=kind, text=text, payload=payload)

    # ---- Stop and New chat ----------------------------------------------------------------------

    def stop(self, channel: str) -> int:
        """End the reply being worked on in a channel, and anything waiting in line. Returns how many."""
        marks = ", ".join("?" for _ in IN_FLIGHT)
        with self.store.write() as db:
            working = db.execute(f"SELECT id, status, payload FROM bot_messages WHERE channel = ? AND role = 'user'"
                                 f" AND status IN ({marks})", (channel, *IN_FLIGHT)).fetchall()
            queued = []
            for row in working:
                if row["status"] == "queued":
                    payload = {**(row_dict(row)["payload"] or {}), "ended": "stopped"}
                    db.execute("UPDATE bot_messages SET status = 'done', attachment = NULL, payload = ? WHERE id = ?",
                               (dumps(payload), row["id"]))
                    queued.append(row["id"])
                elif row["status"] != "stopping":
                    db.execute("UPDATE bot_messages SET status = 'stopping' WHERE id = ?", (row["id"],))
        for message_id in queued:
            self._say(message_id, "answer", words.STOPPED_IN_LINE)
        return len(working)

    def new_chat(self, channel: str) -> dict:
        """Start the conversation afresh. What came before stays saved but is no longer shown or given to the model,
        its open cards are withdrawn, and a reply still being worked on is stopped and never lands."""
        old = self.conversation_row(channel)
        kept = [name for name, kind in self.bot.changes.items() if kind.keep_on_new_chat]
        not_kept = f" AND kind NOT IN ({', '.join('?' for _ in kept)})" if kept else ""
        with self.store.write() as db:
            db.execute("UPDATE bot_messages SET status = 'stopping' WHERE channel = ? AND status IN ('running', 'waiting')",
                       (channel,))
            db.execute("UPDATE bot_messages SET status = 'done', attachment = NULL WHERE channel = ? AND status = 'queued'",
                       (channel,))
            withdrawn = db.execute(f"SELECT message_id FROM bot_cards WHERE channel = ? AND status = 'open'{not_kept}",
                                   (channel, *kept)).fetchall()
            db.execute(f"UPDATE bot_cards SET status = 'superseded', settled_at = ? WHERE channel = ? AND status = 'open'"
                       f"{not_kept}", (now_iso(), channel, *kept))
            for row in withdrawn:
                self.store.mark_shown_again(db, row["message_id"])
            self.store.insert_message(db, conversation_id=old["id"], channel=channel, role="system", kind="new_chat")
            db.execute("INSERT INTO bot_conversations (channel, runner, model, created_at) VALUES (?, ?, ?, ?)",
                       (channel, old["runner"], old["model"], now_iso()))
        return self.conversation_row(channel)

    # ---- Runners --------------------------------------------------------------------------------

    def runners(self, channel: str) -> dict:
        conversation = self.conversation_row(channel)
        return {"runners": [s.as_json() for s in self.bot.registry.statuses()],
                "selected": {"runner": conversation["runner"], "model": conversation["model"]}}

    def select_runner(self, channel: str, runner: str, model: str | None) -> dict:
        model = model or ""
        problem = self.bot.registry.check_choice(runner, model)
        if problem:
            raise Unacceptable(problem)
        conversation = self.conversation_row(channel)
        with self.store.write() as db:
            db.execute("UPDATE bot_conversations SET runner = ?, model = ? WHERE id = ?",
                       (runner, model, conversation["id"]))
        return {"selected": {"runner": runner, "model": model}}

    # ---- Cards, changes and buttons -------------------------------------------------------------

    def apply_card(self, card_id: int, version: str | None) -> dict:
        return self.message_json(self.changes.apply_card(card_id, version))

    def reject_card(self, card_id: int) -> dict:
        return self.message_json(self.changes.reject_card(card_id))

    def undo_change(self, change_id: int) -> dict:
        return self.message_json(self.changes.undo_change(change_id))

    def run_action(self, message_id: int, action: str, value: Any = None) -> dict:
        """A tap on one of a message's buttons: the app's handler runs, and the message comes back as it is now."""
        handler = self.bot.actions.get(action)
        message = self.message_json(message_id)
        if handler is None:
            raise NotFound()

        def update(text: str | None = None, payload: dict | None = None, buttons: list | None = None) -> None:
            with self.store.write() as db:
                if text is not None:
                    db.execute("UPDATE bot_messages SET text = ? WHERE id = ?", (text, message_id))
                values = dict(payload or {})
                if buttons is not None:
                    values["buttons"] = buttons
                self.store.merge_payload(db, message_id, **values)

        def say(kind: str, text: str, payload: dict | None = None, buttons: list | None = None) -> int:
            return self.post(message["channel"], kind, text, payload, buttons=buttons)

        handler(ActionContext(message, value, message["channel"], message["conversation_id"], self.bot.now(),
                              update, say))
        return self.message_json(message_id)

    def image(self, message_id: int, theme: str) -> bytes:
        message = self.message_json(message_id)
        drawn = self.bot.image(message, theme) if self.bot.image is not None else None
        if not drawn:
            raise NotFound()
        return drawn

    # ---- Push fronts (Telegram) -----------------------------------------------------------------

    def outbox(self, channel: str) -> dict:
        """What a front that pushes to its reader still has to show, what it shows that has changed since (`edits`),
        and what is still being worked on."""
        self._refresh(channel)
        conversation = self.conversation_row(channel)
        marks = ", ".join("?" for _ in IN_FLIGHT)
        with self.store.connect() as db:
            working = [row_dict(r) for r in db.execute(
                f"SELECT * FROM bot_messages WHERE channel = ? AND role = 'user' AND status IN ({marks}) ORDER BY id",
                (channel, *IN_FLIGHT)).fetchall()]
            busy_with = {m["id"] for m in working if m["status"] != "queued"}
            undelivered = self._messages_json(db, db.execute(
                "SELECT * FROM bot_messages WHERE conversation_id = ? AND role = 'assistant' AND delivered IS NULL"
                " ORDER BY id", (conversation["id"],)).fetchall())
            # A card waits for the words that go with it, so both arrive as one message.
            replies = [r for r in undelivered if not (r["kind"] == "card" and r["reply_to"] in busy_with)]
            # What the app says unasked keeps the quiet hours at delivery too.
            if self.bot.quiet_hours is not None and self.bot.quiet_hours(self.bot.now()):
                replies = [r for r in replies if not r["payload"].get("unasked")]
            shown = db.execute(
                "SELECT * FROM bot_messages WHERE channel = ? AND role = 'assistant' AND delivered IS NOT NULL"
                " ORDER BY id DESC LIMIT ?", (channel, HISTORY_LIMIT)).fetchall()
            edits = [m for m in self._messages_json(db, list(reversed(shown))) if m["payload"].get("refresh")]
        now = datetime.now(timezone.utc)
        return {
            "replies": replies,
            "edits": edits,
            "in_flight": [{"id": m["id"], "kind": m["kind"], "status": m["status"], "steps": m["steps"] or [],
                           "age_seconds": (now - _parse_time(m["created_at"])).total_seconds()} for m in working],
        }

    def mark_delivered(self, message_id: int, ids: list) -> None:
        with self.store.write() as db:
            message = self.store.message(message_id, db)
            if message is None:
                raise NotFound()
            payload = {k: v for k, v in (message["payload"] or {}).items() if k != "refresh"}
            db.execute("UPDATE bot_messages SET delivered = ?, payload = ? WHERE id = ?",
                       (dumps(ids), dumps(payload), message_id))

    # ---- Working through the queue --------------------------------------------------------------

    def _ensure_worker(self) -> None:
        with self._worker_guard:
            if self._worker is None or not self._worker.is_alive():
                self._worker = threading.Thread(target=self._drain, name=f"bot-{self.bot.name}", daemon=True)
                self._worker.start()

    def wait_idle(self, timeout: float = 30) -> bool:
        """Until nothing is queued or being worked on (for scripts and checks)."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._worker_guard:
                if self._worker is None or not self._worker.is_alive():
                    return True
            time.sleep(0.05)
        return False

    def _next_queued(self) -> int | None:
        with self.store.write() as db:
            row = db.execute("SELECT id FROM bot_messages WHERE status = 'queued' ORDER BY id LIMIT 1").fetchone()
            if row is None:
                return None
            db.execute("UPDATE bot_messages SET status = 'running' WHERE id = ?", (row["id"],))
            return row["id"]

    def _drain(self) -> None:
        while True:
            with self._worker_guard:
                message_id = self._next_queued()
                if message_id is None:
                    self._worker = None
                    return
            try:
                self._handle(message_id)
            except Exception:
                logger.exception("[bot] handling message %s failed", message_id)
                self._say(message_id, "error", words.SOMETHING_WRONG)
            self._finish(message_id)

    def _finish(self, message_id: int) -> None:
        with self.store.connect() as db:
            db.execute("UPDATE bot_messages SET status = 'done', attachment = NULL WHERE id = ?", (message_id,))

    def _overtaken(self, db, message: dict | None) -> bool:
        """The conversation it belongs to was replaced by a New chat while it was being worked out."""
        return message is None or self.store.current_conversation_id(db, message["channel"]) != message["conversation_id"]

    def _abandoned(self, message_id: int) -> bool:
        with self.store.connect() as db:
            return self._overtaken(db, self.store.message(message_id, db))

    def _stopping(self, message_id: int) -> bool:
        with self.store.connect() as db:
            message = self.store.message(message_id, db)
            return message is None or message["status"] == "stopping" or self._overtaken(db, message)

    def _say(self, reply_to: int, kind: str, text: str, payload: dict | None = None) -> int | None:
        """Add a reply, unless a New chat was started while it was being worked out."""
        with self.store.write() as db:
            asked = self.store.message(reply_to, db)
            if self._overtaken(db, asked):
                return None
            return self.store.insert_message(db, conversation_id=asked["conversation_id"], channel=asked["channel"],
                                             role="assistant", kind=kind, text=text, reply_to=reply_to,
                                             payload=payload)

    def add_step(self, message_id: int, step: str) -> None:
        self.store.add_step(message_id, step)

    def _note(self, message_id: int, **values) -> None:
        with self.store.write() as db:
            self.store.merge_payload(db, message_id, **values)

    def _handle(self, message_id: int) -> None:
        message = self.store.message(message_id)
        if message is None or self._abandoned(message_id):
            return
        picture = None
        if message["kind"] != "text":
            handler = self.bot.handlers.get(message["kind"])
            if handler is None:
                self._say(message_id, "error", "I cannot take that kind of message here. Nothing changed.")
                return

            def say(kind: str, text: str, payload: dict | None = None, buttons: list | None = None) -> int | None:
                payload = dict(payload or {})
                if buttons is not None:
                    payload["buttons"] = buttons
                return self._say(message_id, kind, text, payload)

            handed = handler(Incoming(
                message["id"], message["channel"], message["conversation_id"], message["kind"], message["text"],
                message["payload"] or {}, message["attachment"], self.bot.now(), say,
                lambda step: self.add_step(message_id, step), str((message["payload"] or {}).get("page") or ""),
            ))
            if not isinstance(handed, ToModel):
                return
            if handed.text is not None:
                with self.store.connect() as db:
                    db.execute("UPDATE bot_messages SET text = ? WHERE id = ?", (handed.text, message_id))
            picture = handed.picture
        self._converse(message_id, picture)

    def _history(self, message: dict) -> tuple[list[dict], dict]:
        with self.store.connect() as db:
            rows = db.execute("SELECT * FROM bot_messages WHERE conversation_id = ? AND id <= ? ORDER BY id",
                              (message["conversation_id"], message["id"])).fetchall()
            messages = self._messages_json(db, rows, with_args=True)
        return messages[:-1], messages[-1]

    def _converse(self, message_id: int, picture: bytes | None) -> None:
        """Let the model work the reply out with its tools, for up to the time limit or until stopped."""
        bot, registry = self.bot, self.bot.registry
        message = self.store.message(message_id)
        with self.store.connect() as db:
            conversation = dict(db.execute("SELECT * FROM bot_conversations WHERE id = ?",
                                           (message["conversation_id"],)).fetchone())
        selected = self._conversation_json(conversation)
        runner_id, model = selected["runner"], selected["model"]
        runner = registry.get(runner_id)
        if runner is None:
            self._say(message_id, "error", registry.reason(runner_id, "missing"))
            return

        page = str((message["payload"] or {}).get("page") or "")
        ctx = Ctx(message["channel"], bot.now(), message["conversation_id"], page, message_id)
        system = bot.instructions(ctx) if callable(bot.instructions) else str(bot.instructions)
        history, asked = self._history(message)
        text = prompts.build(bot, self._context(ctx), history, asked)
        toolbox = Toolbox(bot, message["channel"], message["conversation_id"], message_id, page)
        clock = _Clock(bot.time_limit_seconds)

        def waited(waiting: bool) -> None:
            clock.on_wait(waiting)
            with self.store.connect() as db:
                db.execute("UPDATE bot_messages SET status = ? WHERE id = ? AND status IN ('running', 'waiting')",
                           ("waiting" if waiting else "running", message_id))

        def should_stop() -> bool:
            return self._stopping(message_id) or clock.left() <= 0

        request = RunRequest(system, text, model, toolbox.specs, toolbox.call_tool,
                             max(clock.left(), MIN_CALL_SECONDS), should_stop, waited, picture)
        try:
            try:
                result = runner.run(request)
            finally:
                toolbox.close()
            # Landing is inside the try, as in the TypeScript package: if it fails after the reply made a card or a change,
            # the error below says so rather than "nothing changed".
            registry.note_success(runner_id)
            said = (result.text or "").strip()
            if not said and not (toolbox.cards or toolbox.changes or toolbox.choices):
                self._say(message_id, "error", words.EMPTY_REPLY.format(label=registry.label(runner_id)))
                return
            self._land(message_id, said, toolbox)
            return
        except RunnerFailure as failure:
            if failure.kind not in ("stopped", "timeout"):
                registry.note_failure(runner_id, failure.kind)
                logger.warning("[bot] %s failed (%s): %s", runner_id, failure.kind,
                               getattr(failure, "detail", "") or failure.message)
                reason = registry.reason(runner_id, failure.kind, failure.message)
                if toolbox.cards or any(item.get("made") for item in toolbox.work):
                    reason = words.partly_done(reason)
                self._say(message_id, "error", reason)
                return
            ended = "stopped" if failure.kind == "stopped" and self._stopping(message_id) else "time"
        except Exception:
            logger.exception("[bot] %s failed", runner_id)
            reason = registry.reason(runner_id, "error")
            if toolbox.cards or any(item.get("made") for item in toolbox.work):
                reason = words.partly_done(reason)
            self._say(message_id, "error", reason)
            return

        self._note(message_id, ended=ended)
        if self._abandoned(message_id):
            return  # a New chat: nobody will see it, so it is not written up
        self.add_step(message_id, words.STEP_WRITING_UP if toolbox.work else words.STEP_STOPPED)
        written = self._write_up(runner, model, system, text, toolbox.work, ended, message_id)
        self._say(message_id, "answer", written, {"ended": ended})

    def _context(self, ctx: Ctx) -> dict:
        context: dict = {"today": ctx.now.date().isoformat()}
        if self.bot.context is None:
            return context
        try:
            given = self.bot.context(ctx)
        except Exception:
            logger.exception("[bot] the app's context failed")
            given = {"error": "The app's overview could not be read just now."}
        if isinstance(given, dict):
            return {**context, **given}
        return {**context, "app": given}

    def _write_up(self, runner, model: str, system: str, text: str, work: list[dict], ended: str,
                  message_id: int) -> str:
        """The model, stopped, says what it had found, on the same runner and model, without tools."""
        if not work:
            return words.STOPPED_BEFORE if ended == "stopped" else words.TIMED_OUT_BEFORE
        fallback = words.STOPPED_FALLBACK_CHANGED if any(w.get("made") for w in work) else words.STOPPED_FALLBACK
        request = RunRequest(system, prompts.wrap_up(self.bot, text, work, ended), model, [],
                             lambda name, args: ToolResult(f"There is no tool called {name}.", True), WRAP_UP_SECONDS,
                             lambda: self._abandoned(message_id))
        try:
            written = (runner.run(request).text or "").strip()
        except Exception as e:
            logger.warning("[bot] writing up a stopped reply failed: %s", e)
            return fallback
        if not written:
            return fallback
        return written if words.says_it_stopped(written) else f"{words.PARTIAL}\n\n{written}"

    def _land(self, message_id: int, said: str, toolbox: Toolbox) -> None:
        attached = dict(toolbox.attached)
        if toolbox.choices:
            self._say(message_id, "answer", said or words.WHICH_ONE, {**attached, "options": toolbox.choices})
        elif said:
            if toolbox.cards and not attached and self._attach_to_card(message_id, toolbox.cards[-1], said):
                return
            self._say(message_id, "answer", said, attached or None)

    def _attach_to_card(self, message_id: int, card_id: int, said: str) -> bool:
        """Put the model's words on the card it made in this reply, so the two arrive as one message."""
        with self.store.write() as db:
            if self._overtaken(db, self.store.message(message_id, db)):
                return True  # nobody is there to read them
            card = self.store.card(card_id, db)
            if card is None or card["status"] != "open":
                return False
            self.store.merge_payload(db, card["message_id"], says=said)
            return True


def _parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))
