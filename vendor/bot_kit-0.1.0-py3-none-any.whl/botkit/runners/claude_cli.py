"""`claude-cli`: Claude Code (`claude -p`) on this machine's existing login, in the bubblewrap sandbox (SPEC §3.1, §3.4).

The model gets the prompt and the app's tools, nothing else: built-in tools off, no settings, no slash commands, no MCP
server but the run's own loopback one (`app`), each of its tools allowed by name, everything else denied without asking
(dontAsk). The CLI's first event says what it started with; unless that is exactly the shape asked for, the run is
killed (`policy`), and until it has been checked the MCP server answers no tool call. Any tool call the model makes to
anything but the app's tools also kills the run. Extracted from household-finance's categorizer/claude_cli.py and
Roadmap Studio's providers/claude.ts.
"""
from __future__ import annotations

import base64
import json
import os
import shutil
import threading
import time
from pathlib import Path

from botkit.mcp import SERVER_NAME, McpServer
from botkit.runners.base import Model, RunnerFailure, RunnerStatus, RunRequest, RunResult, ToolResult, classify
from botkit.runners.common import StatusCache, clean, failure, picture_type
from botkit.runners.config import RunnerConfig
from botkit.runners.sandbox import PrivateHome, SandboxRefused, Waited, build_command, find_binary, find_bwrap, run_process

ID = "claude-cli"
LABEL = "Claude Code"
TOKEN_ENV = "BOT_MCP_TOKEN"  # the CLI expands it inside the MCP config, so the token is never on a command line
CREDENTIAL_NAME = ".credentials.json"
# The CLI adds the account's email to what it sends the model, read from the profile cached in its config file.
_PERSONAL_ACCOUNT_FIELDS = ("emailAddress", "displayName", "fullName", "organizationName")


def scrub_account(home: Path) -> None:
    """Remove everything personal from the CLI's cached profile; the login doesn't depend on it. A fresh
    `profileFetchedAt` stops the CLI fetching the profile, and with it the email, again."""
    file = home / ".claude.json"
    config: dict = {}
    for _ in range(5):  # the CLI may be mid-write
        try:
            config = json.loads(file.read_text()) if file.exists() else {}
            break
        except (OSError, ValueError):
            time.sleep(0.04)
    account = config.get("oauthAccount") or {}
    for name in _PERSONAL_ACCOUNT_FIELDS:
        account.pop(name, None)
    config["oauthAccount"] = {
        "billingType": None, "accountCreatedAt": None, "subscriptionCreatedAt": None, "ccOnboardingFlags": {},
        **account, "profileFetchedAt": int(time.time() * 1000),
    }
    temp = home / ".claude.json.tmp"
    temp.touch(mode=0o600)
    temp.write_text(json.dumps(config))
    os.replace(temp, file)


def claude_args(system: str, model: str, mcp_url: str | None, allowed: list[str], picture: bool) -> list[str]:
    """The exact arguments of a run. With no tools there is no MCP server at all."""
    args = [
        "-p", "--model", model,
        "--output-format", "stream-json", "--verbose", "--include-partial-messages",
        *(["--input-format", "stream-json"] if picture else []),
        "--tools", "", "--disable-slash-commands", "--strict-mcp-config", "--setting-sources", "",
        "--no-session-persistence", "--permission-mode", "dontAsk", "--system-prompt", system,
    ]
    if mcp_url:
        if not mcp_url.startswith("http://127.0.0.1:"):
            raise SandboxRefused("the app's tools are served on loopback only")
        config = {"mcpServers": {SERVER_NAME: {"type": "http", "url": mcp_url,
                                               "headers": {"Authorization": f"Bearer ${{{TOKEN_ENV}}}"}}}}
        args += ["--mcp-config", json.dumps(config), "--allowedTools", *allowed]
    return args


def _with_picture(prompt: str, picture: bytes, kind: str) -> str:
    """The prompt and a picture as the one stream-json message the CLI is given. The picture is seen, not run."""
    return json.dumps({"type": "user", "message": {"role": "user", "content": [
        {"type": "image", "source": {"type": "base64", "media_type": kind, "data": base64.b64encode(picture).decode()}},
        {"type": "text", "text": prompt},
    ]}}) + "\n"


class _Watch:
    """Reads the CLI's stream-json events: checks the launch shape and kills the run on any tool it may not use."""

    def __init__(self, allowed: set[str], checked: threading.Event, stopped: threading.Event) -> None:
        self.allowed = allowed
        self.checked = checked  # set once the launch shape was verified; until then the MCP server answers no call
        self.stopped = stopped  # set when the run is being killed for what it did; the MCP server answers no more
        self.saw_init = False
        self.violation: str | None = None
        self.result_text: str | None = None
        self.result_error: str | None = None
        self.rejected_limit = False

    def stop(self, why: str, kill) -> None:
        if self.violation is None:
            self.violation = why
        self.stopped.set()
        kill("policy")

    def own_tool(self, block: dict) -> bool:
        return block.get("type") == "tool_use" and block.get("name") in self.allowed

    @staticmethod
    def is_tool_use(block) -> bool:
        return isinstance(block, dict) and isinstance(block.get("type"), str) and block["type"].endswith("tool_use")

    def __call__(self, line: str, kill) -> None:
        try:
            event = json.loads(line)
        except ValueError:
            return
        if not isinstance(event, dict):
            return
        kind = event.get("type")
        if not self.saw_init and (kind in ("stream_event", "assistant", "user") or (kind == "result" and not event.get("is_error"))):
            return self.stop("the CLI answered before it said what it started with, so the run could not be checked", kill)
        if kind == "system" and event.get("subtype") == "init":
            self.saw_init = True
            self.check_init(event, kill)
        elif kind == "system" and event.get("subtype") == "permission_denied":
            self.stop(f"the model tried to use the tool {event.get('tool_name')!r}, which this run doesn't have", kill)
        elif kind == "stream_event":
            inner = event.get("event") or {}
            block = inner.get("content_block")
            if inner.get("type") == "content_block_start" and self.is_tool_use(block) and not self.own_tool(block):
                self.stop(f"the model tried to use the tool {block.get('name')!r}", kill)
        elif kind == "assistant":
            for block in (event.get("message") or {}).get("content") or []:
                if self.is_tool_use(block) and not self.own_tool(block):
                    self.stop(f"the model tried to use the tool {block.get('name')!r}", kill)
        elif kind == "rate_limit_event":
            if (event.get("rate_limit_info") or {}).get("status") == "rejected":
                self.rejected_limit = True
        elif kind == "result":
            if isinstance(event.get("result"), str):
                self.result_text = event["result"]
            if event.get("is_error"):
                errors = event.get("errors")
                self.result_error = str(event.get("result") or (" ".join(map(str, errors)) if isinstance(errors, list) else "")
                                        or event.get("subtype") or "the CLI reported an error")

    def check_init(self, event: dict, kill) -> None:
        tools = event.get("tools") if isinstance(event.get("tools"), list) else []
        servers = event.get("mcp_servers") if isinstance(event.get("mcp_servers"), list) else []
        if not self.allowed:
            if tools:
                return self.stop(f"the CLI started with tools available: {', '.join(map(str, tools))}", kill)
            if servers:
                return self.stop("the CLI started with MCP servers attached", kill)
        else:
            # An allowlist: exactly one server, ours, connected, with exactly the tools listed for this run. A server
            # that failed to connect leaves the model with no tools and it would answer from nothing.
            if len(servers) != 1 or (servers[0] or {}).get("name") != SERVER_NAME:
                names = ", ".join(str((s or {}).get("name")) for s in servers) or "none"
                return self.stop(f"the CLI started with MCP servers other than the app's: {names}", kill)
            if servers[0].get("status") != "connected":
                return self.stop(f"the app's tools did not connect to the CLI (it reported {servers[0].get('status')!r})", kill)
            if len(tools) != len(self.allowed) or not all(t in self.allowed for t in tools):
                return self.stop(f"the CLI started with tools other than the app's: {', '.join(map(str, tools)) or 'none'}", kill)
        if event.get("permissionMode") != "dontAsk":
            return self.stop(f"the CLI started in permission mode {event.get('permissionMode')!r}, not dontAsk", kill)
        # Nothing of anyone's own was asked for: no slash commands, skills, extra folders, or plugins but built-in ones.
        extra = [key for key in ("slash_commands", "skills", "additional_directories")
                 if isinstance(event.get(key), list) and event[key]]
        plugins = event.get("plugins") if isinstance(event.get("plugins"), list) else []
        if any((p or {}).get("path") != "builtin" for p in plugins):
            extra.append("plugins")
        if extra:
            return self.stop(f"the CLI started with things this run did not ask for: {', '.join(extra)}", kill)
        self.checked.set()


class ClaudeCliRunner:
    id = ID
    label = LABEL

    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self._cache = StatusCache()
        self._home = PrivateHome("claude", Path(config.claude_home), Path(config.claude_credentials), CREDENTIAL_NAME) \
            if config.claude_home else None

    def _models(self) -> list[Model]:
        return [Model(m, m[:1].upper() + m[1:]) for m in self.config.claude_models]

    def _base_status(self, state: str, detail: str) -> RunnerStatus:
        models = self._models()
        return RunnerStatus(ID, LABEL, state, detail, models, models[0].id if models else None)  # type: ignore[arg-type]

    def status(self) -> RunnerStatus:
        return self._cache.get(self._compute_status)

    def _compute_status(self) -> RunnerStatus:
        if not find_binary("claude", self.config.claude_bin):
            return self._base_status("missing", "The claude CLI was not found on this machine.")
        if not find_bwrap():
            return self._base_status("missing", "bubblewrap (bwrap) is not installed, so the CLI cannot be sandboxed.")
        if self._home is None:
            return self._base_status("missing", "No private home folder is set up for it (claude_home).")
        if not self._home.has_credential():
            return self._base_status("logged_out", "Not logged in on this machine. Run: claude auth login")
        try:
            json.loads(self._home.credential_file.read_text())
        except (OSError, ValueError):
            return self._base_status("logged_out", "The login token file could not be read. Run: claude auth login")
        refused = self._home.refusal()
        if refused:
            return self._base_status("error", f"Refused to run: {refused}")
        return self._base_status("ready", "Logged in.")

    def run(self, request: RunRequest) -> RunResult:
        try:
            result = self._run(request)
        except RunnerFailure as e:
            self._cache.note_failure(e, self._base_status("error", ""))
            raise
        self._cache.note_success()
        return result

    def _fail(self, kind, detail: str = "", message: str | None = None) -> RunnerFailure:
        return failure(kind, LABEL, True, detail, message)

    def _run(self, request: RunRequest) -> RunResult:
        binary = find_binary("claude", self.config.claude_bin)
        if not binary:
            raise self._fail("missing", "the claude CLI was not found")
        bwrap = find_bwrap()
        if not bwrap:
            raise self._fail("missing", "bwrap was not found")
        if self._home is None:
            raise self._fail("missing", "claude_home is not configured")
        home = self._home
        if not home.has_credential():
            raise self._fail("logged_out", f"no login token at {home.credential_file}")
        kind = None
        if request.picture is not None:
            kind = picture_type(request.picture)
            if kind is None:
                raise self._fail("unsupported", "not a PNG, JPEG, GIF or WebP picture",
                                 f"{LABEL} cannot read this kind of picture, so it cannot answer this one. Nothing changed.")

        try:
            with home.one_at_a_time(request.on_wait, request.should_stop):
                return self._run_locked(request, home, binary, bwrap, kind)
        except Waited as e:
            raise self._fail("stopped", str(e)) from None
        except SandboxRefused as e:
            raise self._fail("error", f"refused to run: {e}") from None
        except OSError as e:
            raise self._fail("error", f"could not start: {e}") from None

    def _run_locked(self, request: RunRequest, home: PrivateHome, binary: str, bwrap: str, kind: str | None) -> RunResult:
        checked, stopped = threading.Event(), threading.Event()

        def gated_call(name: str, args: dict) -> ToolResult:
            # Only a run whose launch shape was checked reaches a tool, and none once it is being stopped.
            if not checked.is_set() or stopped.is_set() or request.should_stop():
                return ToolResult("This run may not use tools now.", True)
            return request.call_tool(name, args)

        stdin = _with_picture(request.prompt, request.picture, kind) if kind and request.picture is not None else request.prompt
        server = McpServer(request.tools, gated_call) if request.tools else None
        with home.work_dir() as work:
            try:
                if server:
                    server.__enter__()
                allowed = server.allowed_tools() if server else []
                watch = _Watch(set(allowed), checked, stopped)
                args = claude_args(request.system, request.model, server.url if server else None, allowed, kind is not None)
                env = {"DISABLE_AUTOUPDATER": "1", **({TOKEN_ENV: server.token} if server else {})}
                command, env = build_command(home, work, binary, args, env, ["CLAUDE_CONFIG_DIR"], bwrap)
                scrub_account(home.home)
                try:
                    proc = run_process(command, env, work, stdin, request.timeout_seconds, request.should_stop, watch)
                finally:
                    home.link_credential()
                    scrub_account(home.home)
                    # The CLI keeps debug logs of its MCP connection (address, tool names, timings) under .cache.
                    shutil.rmtree(home.home / ".cache", ignore_errors=True)
            finally:
                if server:
                    server.__exit__(None, None, None)

        killed = proc.killed_for or ""
        if watch.violation or killed.startswith("policy"):
            raise self._fail("policy", watch.violation or killed)
        if killed == "timeout":
            raise self._fail("timeout", f"stopped after {request.timeout_seconds:.0f} seconds")
        if killed == "stopped":
            raise self._fail("stopped", "stopped on request")
        if watch.result_error:
            raise self._fail("rate_limited" if watch.rejected_limit else classify(watch.result_error), watch.result_error)
        if proc.code != 0:
            message = proc.stderr or proc.stdout or f"the CLI exited with code {proc.code}"
            raise self._fail("rate_limited" if watch.rejected_limit else classify(message), clean(message))
        if not watch.saw_init:
            raise self._fail("policy", "the CLI never said what it started with, so the run could not be checked")
        if watch.result_text is None:
            raise self._fail("error", "the CLI ended without a result")
        return RunResult(watch.result_text)
