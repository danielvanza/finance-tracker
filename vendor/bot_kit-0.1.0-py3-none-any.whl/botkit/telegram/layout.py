"""Telegram's HTML (SPEC.md §11): escaping, the model's words with bold leads, bullets and folded long lists, quotes,
fixed-width columns, and cutting a long message into pieces Telegram takes.

Only bold, italics, quotes (folded when long) and fixed-width blocks are used. Every function that returns HTML has
already escaped the text in it; `esc` is for anything else that goes into a layout.
Taken from household-finance's telegram_bot.py.
"""
from __future__ import annotations

import html
import re

TEXT_LIMIT = 3900  # Telegram takes 4096 characters; a little room for the tags a cut closes and reopens
FOLD_OVER = 6  # a list in the model's words longer than this is folded until tapped
MONO_WIDTH = 34  # how many fixed-width characters fit one line of a phone

TAG = re.compile(r"<(/?)(b|i|pre|blockquote)( expandable)?>")
_BOLD = re.compile(r"\*\*(\S(?:.*?\S)?)\*\*")
_ITEM = re.compile(r"^\s*[-*•]\s+")


def esc(text) -> str:
    return html.escape(str(text), quote=False)


def plain_text(text: str) -> str:
    """A message without its layout, for when Telegram will not read the layout."""
    return html.unescape(TAG.sub("", text))


def quote(lines: list[str], folded: bool = False) -> list[str]:
    """Lines (already HTML) set apart as a quote, as one piece of a message. A folded one shows three lines until
    tapped."""
    if not lines:
        return []
    return [f"<blockquote{' expandable' if folded else ''}>" + "\n".join(lines) + "</blockquote>"]


def rich(text: str) -> str:
    """The model's words as Telegram shows them: **leads** in bold, list lines with a bullet, and a list of more than
    FOLD_OVER lines folded until tapped."""
    out: list[str] = []
    items: list[str] = []

    def end_list() -> None:
        out.extend(quote(items, folded=True) if len(items) > FOLD_OVER else [f"• {item}" for item in items])
        items.clear()

    for line in text.split("\n"):
        shown = _BOLD.sub(r"<b>\1</b>", esc(line))
        if _ITEM.match(line):
            items.append(_ITEM.sub("", shown, count=1))
        else:
            end_list()
            out.append(shown)
    end_list()
    return "\n".join(out)


def columns(rows: list[dict]) -> str:
    """Rows `{when, amount, name}` as fixed-width columns (plain text, for a <pre> block): the name is cut to what fits
    a phone, never the date or the amount; the amount drops "€" and the minus sign."""
    amounts = [r["amount"].replace("⁠", "").replace("€", "").removeprefix("-") for r in rows]
    wide = max(len(a) for a in amounts)
    room = max(8, MONO_WIDTH - 6 - 1 - wide - 2)
    lines = []
    for r, amount in zip(rows, amounts):
        name = " ".join(r["name"].split())
        lines.append(f"{r['when']:<6} {amount:>{wide}}  {name if len(name) <= room else name[:room - 1] + '…'}")
    return "\n".join(lines)


def chunks(text: str) -> list[str]:
    """Pieces that fit one Telegram message, broken between lines where possible. A quote or block that is open where
    a piece ends is closed there and opened again in the next piece."""
    pieces, current = [], ""
    open_tags: list[re.Match] = []
    for line in text.split("\n"):
        while len(line) > TEXT_LIMIT:
            if current:
                pieces.append(current)
                current = ""
            pieces.append(line[:TEXT_LIMIT])
            line = line[TEXT_LIMIT:]
        closing = "".join(f"</{tag.group(2)}>" for tag in reversed(open_tags))
        if current and len(current) + 1 + len(line) + len(closing) > TEXT_LIMIT:
            pieces.append(current + closing)
            current = "".join(tag.group(0) for tag in open_tags) + line
        else:
            current = f"{current}\n{line}" if current else line
        for tag in TAG.finditer(line):
            if not tag.group(1):
                open_tags.append(tag)
            elif open_tags:
                open_tags.pop()
    if current.strip():
        pieces.append(current)
    return pieces or [" "]
