"""What an app hands the kit (SPEC.md §2, §4, §6, §7): its tools, its kinds of change and the contexts they run in."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Literal

DOING = {
    "type": "string",
    "description": ("What you are doing, in a few plain words the person sees in the live log, such as "
                    "'Checking notes about the garden'. No query text, table or column names."),
}


@dataclass
class Ctx:
    """Where a prompt, a context or the starter buttons are for. `message_id` is the person's message being answered
    (None for the starter buttons) and `page` what they had on screen when they sent it."""
    channel: str
    now: datetime
    conversation_id: int | None = None
    page: str = ""
    message_id: int | None = None


@dataclass
class ToolContext:
    """The conversation a tool call belongs to, with the live log and the write-up's notebook.

    `state` is one reply's scratch space, shared by every tool call in that reply (e.g. a private copy of the
    data built on first use); `on_close(fn)` runs fn once the reply's run has ended, however it ended.
    `attach(**payload)` adds keys to the payload of the answer the reply ends in (e.g. a chart to draw under it);
    an answer with something attached is not folded into a card made in the same reply.
    """
    channel: str
    conversation_id: int
    message_id: int
    now: datetime
    step: Callable[[str], None]
    found: Callable[[str, str], None]
    state: dict = field(default_factory=dict)
    on_close: Callable[[Callable[[], None]], None] = lambda fn: None
    attach: Callable[..., None] = lambda **payload: None
    page: str = ""


@dataclass
class Tool:
    """`run(args, ctx)` returns the text the model reads, or `(text, is_error)`. `step` is the live log's line
    when the model's own `doing` words are missing or read like a query."""
    name: str
    description: str
    input_schema: dict
    run: Callable[[dict, ToolContext], Any]
    step: str = "Looking something up"


@dataclass
class ChangeContext:
    """Where a change is previewed, applied or undone. `message_id` is the person's message that asked for it."""
    channel: str
    conversation_id: int
    message_id: int | None
    now: datetime
    card_id: int | None = None
    change_id: int | None = None
    page: str = ""  # what the person had on screen when they asked for it (SPEC §9)


@dataclass
class Preview:
    lines: list[str]
    data: Any = None
    note: str | None = None

    def as_json(self) -> dict:
        return {"lines": list(self.lines), "data": self.data, "note": self.note}

    @classmethod
    def from_json(cls, value: dict) -> "Preview":
        return cls(lines=list(value.get("lines") or []), data=value.get("data"), note=value.get("note"))


@dataclass
class Applied:
    lines: list[str] | None = None
    undo: Any = None  # immediate changes: what restores the previous state
    result: Any = None


class ChangeError(Exception):
    """The app will not make this change; the reason is shown to the model or on the card."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


class Stale(Exception):
    """The data changed since the preview was shown; `preview` is what the change would do now."""

    def __init__(self, preview: Preview):
        super().__init__("stale")
        self.preview = preview


@dataclass
class ChangeKind:
    """`for_model=False`: only the app offers it (`Bot.offer`), the model is never shown it. `keep_on_new_chat`:
    an open card of this kind is not withdrawn by New chat. `buttons(card, message)` gives the card's buttons
    (SPEC §7) from its stored state: `card` is the card row (status, preview, result …), `message` its message
    (channel, payload); without it the card carries the buttons in its message's payload."""
    name: str
    mode: Literal["card", "immediate"]
    signature: str
    preview: Callable[[dict, ChangeContext], Preview]
    apply: Callable[[dict, Preview, ChangeContext], Applied]
    undo: Callable[[Any, ChangeContext], str | None] | None = None
    describe: str = ""
    labels: dict = field(default_factory=dict)  # heading, apply, reject, rejected (what a declined card says)
    for_model: bool = True
    keep_on_new_chat: bool = False
    buttons: Callable[[dict, dict], list[dict]] | None = None


@dataclass
class Incoming:
    """A person's message of an app kind (file, photo, voice …), handed to the app's handler in the worker.

    The handler answers it itself with `say` and returns None, or returns `ToModel` to have the model answer.
    """
    id: int
    channel: str
    conversation_id: int
    kind: str
    text: str
    payload: dict
    attachment: bytes | None
    now: datetime
    say: Callable[..., int | None]  # say(kind, text, payload=None, buttons=None)
    step: Callable[[str], None]
    page: str = ""  # what the person had on screen when they sent it


@dataclass
class ToModel:
    """Hand a message to the model. `text` replaces what the message says (e.g. what was heard in a voice note)."""
    text: str | None = None
    picture: bytes | None = None


@dataclass
class ActionContext:
    """A tap on one of a message's buttons. `message` is the Message JSON as the UI has it."""
    message: dict
    value: Any
    channel: str
    conversation_id: int
    now: datetime
    update: Callable[..., None]  # update(text=None, payload=None (merged in), buttons=None)
    say: Callable[..., int | None]  # say(kind, text, payload=None, buttons=None)
