"""The two things the front talks to: Telegram's Bot API, and the app through the kit's HTTP API (SPEC.md §9)."""
from __future__ import annotations

import json

import httpx

POLL_SECONDS = 10

# A bad answer from Telegram itself: refused, unreachable, or not JSON at all.
TELEGRAM_FAILED = (RuntimeError, httpx.HTTPError, ValueError)


class AppDown(Exception):
    """A request to the app failed. `unknown` means it may have got through, so its outcome can't be stated."""

    def __init__(self, message: str, unknown: bool):
        super().__init__("app unavailable")
        self.message = message
        self.unknown = unknown


class Telegram:
    def __init__(self, token: str, base: str = "https://api.telegram.org"):
        base = base.rstrip("/")
        self._api = f"{base}/bot{token}"
        self._files = f"{base}/file/bot{token}"
        self._http = httpx.Client(timeout=httpx.Timeout(15, connect=5))
        # Waiting for news has its own connection, so a stalled wait is noticed fast and can't hold up a send.
        self._polling = httpx.Client(timeout=httpx.Timeout(POLL_SECONDS + 5, connect=5))

    def call(self, method: str, **params):
        return self._result(method, self._http.post(f"{self._api}/{method}", json=params))

    def send_photo(self, chat_id: int, picture: bytes, name: str = "picture.png", mime: str = "image/png"):
        response = self._http.post(f"{self._api}/sendPhoto", data={"chat_id": chat_id},
                                   files={"photo": (name, picture, mime)})
        return self._result("sendPhoto", response)

    def get_updates(self, **params):
        return self._result("getUpdates", self._polling.post(f"{self._api}/getUpdates", json=params))

    @staticmethod
    def _result(method: str, response: httpx.Response):
        body = response.json()
        if not body.get("ok"):
            raise RuntimeError(f"{method}: {body.get('description', response.status_code)}")
        return body["result"]

    def download(self, file_id: str) -> bytes:
        path = self.call("getFile", file_id=file_id)["file_path"]
        response = self._http.get(f"{self._files}/{path}")
        response.raise_for_status()
        return response.content


class AppApi:
    """The kit's HTTP API (SPEC.md §9) for one channel. Every failure is an AppDown with what to tell the person."""

    def __init__(self, base: str, channel: str, texts):
        self._base = base.rstrip("/")
        self.channel = channel
        self._texts = texts
        self._http = httpx.Client(timeout=60)

    def _request(self, method: str, path: str, raw: bool = False, **kwargs):
        try:
            response = self._http.request(method, f"{self._base}{path}", **kwargs)
        except (httpx.ConnectError, httpx.ConnectTimeout) as e:
            raise AppDown(self._texts.app_down, unknown=False) from e
        except httpx.HTTPError as e:
            raise AppDown(self._texts.app_unsure, unknown=True) from e
        if response.status_code >= 500:
            raise AppDown(self._texts.app_unsure, unknown=True)
        if response.status_code >= 400:
            raise AppDown(self._texts.app_refused, unknown=False)
        return response.content if raw else response.json()

    def conversation(self) -> dict:
        return self._request("GET", "/conversation", params={"channel": self.channel})

    def send(self, text: str | None = None, choice_id=None) -> dict:
        body = {"channel": self.channel}
        if choice_id is not None:
            body["choice_id"] = choice_id
        else:
            body["text"] = text
        return self._request("POST", "/messages", json=body)

    def upload(self, kind: str, name: str, content: bytes, caption: str = "") -> dict:
        return self._request("POST", f"/uploads/{kind}", data={"channel": self.channel, "caption": caption},
                             files={"file": (name, content)})

    def stop(self) -> int:
        return self._request("POST", "/stop", json={"channel": self.channel})["stopped"]

    def new_chat(self) -> dict:
        return self._request("POST", "/new", json={"channel": self.channel})

    def apply(self, card_id: int, version: str) -> dict:
        return self._request("POST", f"/cards/{card_id}/apply", json={"version": version})

    def reject(self, card_id: int) -> dict:
        return self._request("POST", f"/cards/{card_id}/reject")

    def undo(self, change_id: int) -> dict:
        return self._request("POST", f"/changes/{change_id}/undo")

    def action(self, message_id: int, action: str, value=None) -> dict:
        return self._request("POST", f"/messages/{message_id}/actions/{action}", json={"value": value})

    def outbox(self) -> dict:
        return self._request("GET", "/outbox", params={"channel": self.channel})

    def delivered(self, message_id: int, telegram_ids: list[int]) -> None:
        self._request("POST", f"/messages/{message_id}/delivered", json={"ids": telegram_ids})

    def image(self, message_id: int, theme: str = "day") -> bytes:
        return self._request("GET", f"/messages/{message_id}/image", raw=True, params={"theme": theme})


def encode_value(value) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def decode_value(text: str):
    try:
        return json.loads(text)
    except ValueError:
        return text
