"""`codex-cli`: Codex (`codex exec --json`) on this machine's existing login, in the bubblewrap sandbox (SPEC §3.1, §3.4).

Every built-in feature that is a tool is disabled, the user's config and rules are ignored, and the only MCP server is
the run's own loopback one (`app`), reached with a bearer token that is in the environment, never on the command line.
The JSON stream is watched: any item other than the model's words, its reasoning, or a call to one of the `app` server's
tools kills the run (`policy`). A picture is attached with `--image` from a file inside the sandbox's work dir.
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

from botkit.mcp import SERVER_NAME, McpServer
from botkit.runners.base import Model, RunnerFailure, RunnerStatus, RunRequest, RunResult, ToolResult, classify
from botkit.runners.common import StatusCache, clean, failure, picture_type
from botkit.runners.config import RunnerConfig
from botkit.runners.sandbox import (
    SANDBOX_WORK, PrivateHome, SandboxRefused, Waited, build_command, find_binary, find_bwrap, run_process,
)

ID = "codex-cli"
LABEL = "Codex"
TOKEN_ENV = "BOT_MCP_TOKEN"
CREDENTIAL_NAME = "auth.json"
MODELS_TTL = 3600.0
DISABLED_FEATURES = ("shell_tool", "unified_exec", "plugins", "apps", "multi_agent", "browser_use", "in_app_browser",
                     "computer_use", "image_generation", "view_image", "goals", "hooks", "memories")
SAFE_ITEMS = {"agent_message", "reasoning"}
_EXTENSIONS = {"image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp"}


def codex_args(model: str, mcp_url: str | None, picture_file: str | None) -> list[str]:
    """The exact arguments of a run. With no tools there is no MCP server at all."""
    args = ["exec", *(["--image", picture_file] if picture_file else []),
            "--json", "--ephemeral", "--skip-git-repo-check", "--sandbox", "read-only",
            "--ignore-user-config", "--ignore-rules", "-m", model, "-c", 'web_search="disabled"']
    if mcp_url:
        if not mcp_url.startswith("http://127.0.0.1:"):
            raise SandboxRefused("the app's tools are served on loopback only")
        args += ["-c", f"mcp_servers.{SERVER_NAME}.url={json.dumps(mcp_url)}",
                 "-c", f'mcp_servers.{SERVER_NAME}.bearer_token_env_var="{TOKEN_ENV}"',
                 "-c", f'mcp_servers.{SERVER_NAME}.default_tools_approval_mode="approve"']
    for feature in DISABLED_FEATURES:
        args += ["--disable", feature]
    return [*args, "-"]


class _Watch:
    def __init__(self, stopped: threading.Event) -> None:
        self.stopped = stopped
        self.violation: str | None = None
        self.texts: list[str] = []
        self.error: str | None = None
        self.notes: list[str] = []

    def __call__(self, line: str, kill) -> None:
        try:
            event = json.loads(line)
        except ValueError:
            return
        if not isinstance(event, dict):
            return
        kind = str(event.get("type") or "")
        item = event.get("item") if isinstance(event.get("item"), dict) else None
        if kind.startswith("item.") and item is not None:
            item_type = item.get("type")
            if item_type == "error":  # a problem reported as an item (not a tool): kept as the reason if the run fails
                self.notes.append(str(item.get("message") or ""))
                return
            allowed = item_type in SAFE_ITEMS or (item_type == "mcp_tool_call" and item.get("server") == SERVER_NAME)
            if not allowed:
                what = f"command {str(item.get('command'))[:120]!r}" if item.get("command") else \
                    f"{item_type} ({item.get('server')}.{item.get('tool')})" if item_type == "mcp_tool_call" else f"a {item_type} item"
                self.violation = f"the model tried to use {what}"
                self.stopped.set()
                kill("policy")
                return
            if kind == "item.completed" and item_type == "agent_message" and isinstance(item.get("text"), str):
                self.texts.append(item["text"])
        elif kind in ("turn.failed", "error"):
            error = event.get("error") if isinstance(event.get("error"), dict) else {}
            self.error = str(event.get("message") or error.get("message") or "the CLI reported an error")


class CodexCliRunner:
    id = ID
    label = LABEL

    def __init__(self, config: RunnerConfig) -> None:
        self.config = config
        self._cache = StatusCache()
        self._home = PrivateHome("codex", Path(config.codex_home), Path(config.codex_credentials), CREDENTIAL_NAME) \
            if config.codex_home else None
        self._models: tuple[float, list[Model]] | None = None
        self._models_lock = threading.Lock()

    def _fail(self, kind, detail: str = "", message: str | None = None) -> RunnerFailure:
        return failure(kind, LABEL, True, detail, message)

    # ---- status -------------------------------------------------------------------------------------------------

    def _base_status(self, state: str, detail: str, models: list[Model] | None = None) -> RunnerStatus:
        models = models if models is not None else (self._models[1] if self._models else [])
        return RunnerStatus(ID, LABEL, state, detail, models, models[0].id if models else None)  # type: ignore[arg-type]

    def status(self) -> RunnerStatus:
        return self._cache.get(self._compute_status)

    def _sandboxed(self, args: list[str], timeout: float = 20) -> tuple[int | None, str, str]:
        """A short codex command (not a model run) in the sandbox: `login status`, `debug models`."""
        assert self._home is not None
        binary, bwrap = find_binary("codex", self.config.codex_bin), find_bwrap()
        assert binary and bwrap
        with self._home.work_dir() as work:
            command, env = build_command(self._home, work, binary, args, {}, ["CODEX_HOME"], bwrap)
            result = run_process(command, env, work, "", timeout)
            self._home.link_credential()
        return result.code, result.stdout, result.stderr

    def models(self) -> list[Model]:
        """`codex debug models`, visibility `list`, in priority order; cached for an hour (and on disk, for a restart)."""
        with self._models_lock:
            if self._models and time.monotonic() < self._models[0]:
                return self._models[1]
        assert self._home is not None
        saved = self._home.base / "models.json"
        models: list[Model] = []
        try:
            code, stdout, _ = self._sandboxed(["debug", "models"])
            listed = [m for m in json.loads(stdout).get("models", []) if m.get("visibility") == "list"]
            listed.sort(key=lambda m: m.get("priority", 99))
            models = [Model(str(m["slug"]), str(m.get("display_name") or m["slug"])) for m in listed if m.get("slug")]
            if models:
                saved.write_text(json.dumps([{"id": m.id, "label": m.label} for m in models]))
        except (ValueError, OSError, SandboxRefused, KeyError, AttributeError):
            pass
        if not models:
            try:
                models = [Model(m["id"], m["label"]) for m in json.loads(saved.read_text())]
            except (OSError, ValueError, KeyError, TypeError):
                models = []
        with self._models_lock:
            self._models = (time.monotonic() + (MODELS_TTL if models else 60), models)
        return models

    def _compute_status(self) -> RunnerStatus:
        if not find_binary("codex", self.config.codex_bin):
            return self._base_status("missing", "The codex CLI was not found on this machine.", [])
        if not find_bwrap():
            return self._base_status("missing", "bubblewrap (bwrap) is not installed, so the CLI cannot be sandboxed.", [])
        if self._home is None:
            return self._base_status("missing", "No private home folder is set up for it (codex_home).", [])
        if not self._home.has_credential():
            return self._base_status("logged_out", "Not logged in on this machine. Run: codex login", [])
        try:
            models = self.models()
            code, stdout, stderr = self._sandboxed(["login", "status"])
        except SandboxRefused as e:
            return self._base_status("error", f"Refused to run: {e}", [])
        output = f"{stdout}\n{stderr}"
        if "logged in" in output.lower() and "not logged in" not in output.lower():
            return self._base_status("ready", clean(stdout or "Logged in.", 120), models)
        return self._base_status("logged_out", "Not logged in on this machine. Run: codex login", models)

    # ---- run ----------------------------------------------------------------------------------------------------

    def run(self, request: RunRequest) -> RunResult:
        try:
            result = self._run(request)
        except RunnerFailure as e:
            self._cache.note_failure(e, self._base_status("error", ""))
            raise
        self._cache.note_success()
        return result

    def _run(self, request: RunRequest) -> RunResult:
        binary = find_binary("codex", self.config.codex_bin)
        if not binary:
            raise self._fail("missing", "the codex CLI was not found")
        bwrap = find_bwrap()
        if not bwrap:
            raise self._fail("missing", "bwrap was not found")
        if self._home is None:
            raise self._fail("missing", "codex_home is not configured")
        if not self._home.has_credential():
            raise self._fail("logged_out", f"no login token at {self._home.credential_file}")
        kind = None
        if request.picture is not None:
            kind = picture_type(request.picture)
            if kind is None:
                raise self._fail("unsupported", "not a PNG, JPEG, GIF or WebP picture",
                                 f"{LABEL} cannot read this kind of picture, so it cannot answer this one. Nothing changed.")
        try:
            with self._home.one_at_a_time(request.on_wait, request.should_stop):
                return self._run_locked(request, self._home, binary, bwrap, kind)
        except Waited as e:
            raise self._fail("stopped", str(e)) from None
        except SandboxRefused as e:
            raise self._fail("error", f"refused to run: {e}") from None
        except OSError as e:
            raise self._fail("error", f"could not start: {e}") from None

    def _run_locked(self, request: RunRequest, home: PrivateHome, binary: str, bwrap: str, kind: str | None) -> RunResult:
        stopped = threading.Event()

        def gated_call(name: str, args: dict) -> ToolResult:
            if stopped.is_set() or request.should_stop():
                return ToolResult("This run may not use tools now.", True)
            return request.call_tool(name, args)

        stdin = f"<instructions>\n{request.system}\n</instructions>\n\n{request.prompt}"
        server = McpServer(request.tools, gated_call) if request.tools else None
        watch = _Watch(stopped)
        with home.work_dir() as work:
            picture_file = None
            if kind and request.picture is not None:
                name = f"picture.{_EXTENSIONS[kind]}"
                (work / name).write_bytes(request.picture)
                picture_file = f"{SANDBOX_WORK}/{name}"
            try:
                if server:
                    server.__enter__()
                args = codex_args(request.model, server.url if server else None, picture_file)
                env = {TOKEN_ENV: server.token} if server else {}
                command, env = build_command(home, work, binary, args, env, ["CODEX_HOME"], bwrap)
                try:
                    proc = run_process(command, env, work, stdin, request.timeout_seconds, request.should_stop, watch)
                finally:
                    home.link_credential()
            finally:
                if server:
                    server.__exit__(None, None, None)

        killed = proc.killed_for or ""
        if watch.violation or killed.startswith("policy"):
            raise self._fail("policy", watch.violation or killed)
        if killed == "timeout":
            raise self._fail("timeout", f"stopped after {request.timeout_seconds:.0f} seconds")
        if killed == "stopped":
            raise self._fail("stopped", "stopped on request")
        if watch.error:
            raise self._fail(classify(watch.error), watch.error)
        if proc.code != 0:
            message = " ".join(watch.notes) or proc.stderr or f"the CLI exited with code {proc.code}"
            raise self._fail(classify(message), clean(message))
        if not watch.texts:
            raise self._fail("error", " ".join(watch.notes) or "the CLI ended without an answer")
        return RunResult(watch.texts[-1])
